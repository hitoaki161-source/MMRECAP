"""
Automated Test Suite for Myanmar Recap Studio Backend.
Covers:
1. Health endpoint checks
2. Invalid file upload validation & unsupported codec detection
3. Task queue creation, polling, and status transitions
4. Myanmar text chunking and TTS task handling
5. Error recovery and graceful failure responses
"""

import os
import io
import pytest
from fastapi.testclient import TestClient

# Ensure app can be imported
from app import app, jobs

client = TestClient(app)

def test_health_endpoint():
    """Verify health check returns valid JSON with component statuses"""
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert "status" in data
    assert "ffmpegAvailable" in data
    assert "ttsAvailable" in data
    assert data["activeBackend"] == "local"

def test_invalid_upload_extension():
    """Ensure unsupported media extensions return HTTP 415 with bilingual error"""
    fake_file = io.BytesIO(b"dummy corrupted payload")
    response = client.post(
        "/api/upload",
        files={"video": ("corrupted_document.exe", fake_file, "application/octet-stream")},
    )
    assert response.status_code == 415
    data = response.json()
    assert "detail" in data
    assert "မထောက်ပံ့သော ဖိုင်အမျိုးအစားဖြစ်ပါသည်" in data["detail"]

def test_valid_video_upload():
    """Test valid video container upload"""
    fake_video = io.BytesIO(b"\x00\x00\x00 ftypmp42\x00\x00\x00\x00mp42isom")
    response = client.post(
        "/api/upload",
        files={"video": ("test_clip.mp4", fake_video, "video/mp4")},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "filename" in data
    assert data["originalName"] == "test_clip.mp4"

def test_job_not_found():
    """Verify polling a non-existent job returns 404"""
    response = client.get("/api/jobs/non_existent_job_123")
    assert response.status_code == 404

def test_transcribe_missing_file():
    """Verify transcription fails gracefully if referenced video does not exist"""
    response = client.post(
        "/api/transcribe",
        json={"filename": "ghost_movie_file_that_does_not_exist.mp4"},
    )
    assert response.status_code == 404

def test_empty_translation_request():
    """Verify translation rejects empty text"""
    response = client.post(
        "/api/translate",
        json={"originalText": "   "},
    )
    assert response.status_code == 400

def test_tts_task_creation():
    """Verify TTS task creation returns a tracked job id"""
    burmese_sample = "ဒီဇာတ်ကားမှာတော့ ဇာတ်လိုက်ကျော်ကြီးက မြို့သစ်ကို ရောက်ရှိလာခဲ့ပါတယ်။"
    response = client.post(
        "/api/tts",
        json={
            "text": burmese_sample,
            "voiceId": "my-MM-NilarNeural",
            "rate": "+0%",
            "pitch": "+0Hz",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert "jobId" in data
    assert data["jobId"] in jobs

    # Poll status of the newly created job
    job_res = client.get(f"/api/jobs/{data['jobId']}")
    assert job_res.status_code == 200
    job_info = job_res.json()
    assert job_info["type"] == "tts"
    assert "statusMessageBurmese" in job_info

def test_empty_tts_request():
    """Verify TTS fails with 400 when text is missing"""
    response = client.post(
        "/api/tts",
        json={"text": ""},
    )
    assert response.status_code == 400
