@echo off
chcp 65001 >nul
title Myanmar Recap Studio - Local Windows Server

echo =====================================================================
echo       မြန်မာ ရုပ်ရှင် Recap စတူဒီယို (Myanmar Recap Studio)
echo             Windows 10 / Windows 11 Local Server Launcher
echo =====================================================================
echo.

:: 1. Check Python installation
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python ကို ရှာမတွေ့ပါ။ (Python is not installed or not in PATH).
    echo ကျေးဇူးပြု၍ Python 3.10 သို့မဟုတ် 3.11 ကို python.org မှ ဒေါင်းလုဒ်ဆွဲပြီး
    echo "Add python.exe to PATH" ကို အမှန်ခြစ်၍ Install လုပ်ပေးပါ။
    echo.
    pause
    exit /b 1
)

echo [✓] Python စစ်ဆေးပြီးပါပြီ။

:: 2. Check FFmpeg
ffmpeg -version >nul 2>&1
if %errorlevel% neq 0 (
    if not exist "%~dp0ffmpeg\bin\ffmpeg.exe" (
        echo [WARNING] FFmpeg ကို PATH တွင် ရှာမတွေ့ပါ။
        echo setup_ffmpeg_windows.bat ကို ဖွင့်၍ FFmpeg ကို အလိုအလျောက် သွင်းယူနိုင်ပါသည်။
        echo.
    ) else (
        echo [✓] Local FFmpeg တွေ့ရှိပါသည် (%~dp0ffmpeg\bin\ffmpeg.exe)
        set "PATH=%~dp0ffmpeg\bin;%PATH%"
    )
) else (
    echo [✓] FFmpeg စစ်ဆေးပြီးပါပြီ။
)

:: 3. Setup Virtual Environment
if not exist "%~dp0venv" (
    echo [*] Python Virtual Environment (venv) အသစ် ဖန်တီးနေပါသည်...
    python -m venv "%~dp0venv"
)

call "%~dp0venv\Scripts\activate.bat"

:: 4. Install / Update Dependencies
echo [*] လိုအပ်သော Packages များကို စစ်ဆေးသွင်းယူနေပါသည် (pip install)...
python -m pip install --upgrade pip >nul 2>&1
pip install -r "%~dp0requirements.txt"

:: 5. Whisper Model Configuration
echo.
echo =====================================================================
echo Whisper Model အရွယ်အစား ရွေးချယ်ပါ (Select Model Size):
echo 1) base   (ပေါ့ပါးမြန်ဆန်သည် - CPU အတွက် အထူးသင့်တော်သည်) [Default]
echo 2) small  (တိကျမှု ပိုကောင်းသည် - RAM 4GB+ / CPU or GPU)
echo 3) medium (တိကျမှု အကောင်းဆုံး - RAM 8GB+ / Dedicated GPU)
echo =====================================================================
set /p model_choice="ရွေးချယ်မှု နံပါတ်ရိုက်ထည့်ပါ (1, 2, or 3) [Enter for 1]: "

if "%model_choice%"=="2" (
    set "WHISPER_MODEL_SIZE=small"
) else if "%model_choice%"=="3" (
    set "WHISPER_MODEL_SIZE=medium"
) else (
    set "WHISPER_MODEL_SIZE=base"
)

set "WHISPER_DEVICE=cpu"
echo [*] Whisper Model: %WHISPER_MODEL_SIZE% (CPU Mode)

:: 6. Launch FastAPI Server
echo.
echo =====================================================================
echo [*] Local Backend Server ကို စတင်ဖွင့်လှစ်နေပါသည်:
echo [*] Server URL: http://127.0.0.1:7860
echo =====================================================================
echo.

start "" "http://127.0.0.1:7860/docs"
python "%~dp0app.py"

pause
