# Myanmar Recap Studio - Windows 10 & 11 Local Setup Guide
## (မြန်မာ ရုပ်ရှင် Recap စတူဒီယို - Windows ဒေသတွင်း တပ်ဆင်အသုံးပြုနည်း လမ်းညွှန်)

ဤ Folder တွင် Windows 10 နှင့် Windows 11 ကွန်ပျူတာများတွင် အင်တာနက် သို့မဟုတ် ဒေသတွင်း ကွန်ပျူတာစွမ်းအားဖြင့် run နိုင်သော Python FastAPI Backend ပါဝင်ပါသည်။

---

## ၁။ လိုအပ်ချက်များ (System Requirements)

1. **Operating System**: Windows 10 (64-bit) သို့မဟုတ် Windows 11
2. **Python**: Python 3.10 သို့မဟုတ် 3.11 ([python.org](https://www.python.org/downloads/) မှ ရယူပါ)
   - *အရေးကြီးချက်*: Python သွင်းချိန်တွင် **"Add python.exe to PATH"** ကို အမှန်ခြစ် ပေးရန် မမေ့ပါနှင့်။
3. **FFmpeg**: ဗီဒီယို/အသံ ခွဲထုတ်ရန်နှင့် WAV သို့ ပြောင်းရန် လိုအပ်ပါသည်။
4. **RAM**: အနည်းဆုံး 4GB (8GB သို့မဟုတ် GPU ပါက ပိုမိုမြန်ဆန်သည်)

---

## ၂။ အလွယ်တကူ တပ်ဆင်အသုံးပြုနည်း (Quick Start)

### အဆင့် ၁: FFmpeg စစ်ဆေးခြင်း/သွင်းယူခြင်း
Folder ထဲရှိ **`setup_ffmpeg_windows.bat`** ကို Double Click နှိပ်၍ Run ပေးပါ။
- FFmpeg မရှိသေးပါက အလိုအလျောက် ဒေါင်းလုဒ်ဆွဲပြီး bin folder ထဲသို့ ထည့်သွင်းပေးပါမည်။

### အဆင့် ၂: Backend Server စတင်ဖွင့်လှစ်ခြင်း
Folder ထဲရှိ **`start.bat`** ကို Double Click နှိပ်ပါ။
- Script မှ Python Virtual Environment (venv) ကို အလိုအလျောက် တည်ဆောက်ပေးပါမည်။
- `requirements.txt` မှ packages များကို install လုပ်ပေးပါမည်။
- Whisper Model အရွယ်အစားကို မေးမြန်းပါမည်:
  - `1) base` (ပေါ့ပါးမြန်ဆန်သည် - CPU အတွက် အထူးသင့်တော်သည်)
  - `2) small` (တိကျမှု ပိုမိုကောင်းမွန်သည်)
  - `3) medium` (အကောင်းဆုံး တိကျမှု - Dedicated GPU သို့မဟုတ် RAM 8GB+)
- Backend Server သည် **`http://127.0.0.1:7860`** တွင် အောင်မြင်စွာ စတင်လည်ပတ်ပါမည်။

---

## ၃။ အင်္ဂါရပ်များနှင့် လုပ်ဆောင်ချက်များ (Key Features)

1. **ဗီဒီယိုတင်ခြင်း (Video Upload)**:
   - MP4, MOV, MKV, WebM ဖိုင်များကို အထောက်အပံ့ပေးသည်။
   - FFmpeg ဖြင့် ဗီဒီယိုမှ အသံ (16kHz mono audio) ကို အလိုအလျောက် သီးသန့် ခွဲထုတ်ယူသည်။
2. **စာသားဖော်ယူခြင်း (Whisper Speech-to-Text)**:
   - ဒေသတွင်း `faster-whisper` အင်ဂျင်ကို အသုံးပြုထားသောကြောင့် အသံမှ စာသားအဖြစ် အချိန်မှတ် (timestamps) များဖြင့် တိကျစွာ ထုတ်ယူပေးသည်။
3. **မြန်မာဘာသာ ရုပ်ရှင် Recap စတိုင် ပြောင်းလဲခြင်း**:
   - မူရင်းစာသားများကို မြန်မာ ယူနီကုဒ်ဖြင့် သဘာဝကျသော ရုပ်ရှင် recap ဇာတ်ကြောင်းပြော ပုံစံအဖြစ် အဆင်ပြေစွာ ဘာသာပြန်ခြင်း/ပြင်ဆင်ခြင်း။
4. **မြန်မာ အသံဇာတ်ကြောင်းဖန်တီးခြင်း (Edge TTS)**:
   - Microsoft Edge TTS ၏ တရားဝင် မြန်မာအသံများဖြစ်သော `my-MM-NilarNeural` (အမျိုးသမီးသံ) နှင့် `my-MM-ThihaNeural` (အမျိုးသားသံ) တို့ဖြင့် သဘာဝကျသော အသံဖိုင် ဖန်တီးပေးသည်။
   - ရှည်လျားသော စာသားများကို ဝါကျအလိုက် အလိုအလျောက် ပိုင်းဖြတ်၍ FFmpeg ဖြင့် ပေါင်းစပ်ပေးသည်။
   - WAV နှင့် MP3 ဖိုင်များဖြင့် ဒေါင်းလုဒ်ရယူနိုင်သည်။

---

## ၄။ ပြဿနာဖြေရှင်းနည်းများ (Troubleshooting)

| ပြဿနာ (Issue) | ဖြေရှင်းနည်း (Solution) |
|---|---|
| **Python is not recognized** | Python သွင်းထားသော်လည်း PATH ထဲ မရောက်သေးပါက Python Installer ကို ပြန်ဖွင့်ပြီး "Modify" > "Add to PATH" ကို ရွေးချယ်ပါ။ |
| **FFmpeg not found** | `setup_ffmpeg_windows.bat` ကို ပြန် run ပါ သို့မဟုတ် PowerShell တွင် `winget install Gyan.FFmpeg` ရိုက်ထည့်ပါ။ |
| **Edge TTS Connection Error** | Edge TTS သည် အသံထုတ်ယူရန် အင်တာနက်ချိတ်ဆက်မှု လိုအပ်ပါသည်။ အင်တာနက် ချိတ်ဆက်ထားခြင်း ရှိမရှိ စစ်ဆေးပါ။ |
| **Out of Memory on CPU** | Whisper Model ကို `medium` အစား `base` သို့ ပြောင်းလဲအသုံးပြုပါ။ |

---

## ၅။ စမ်းသပ်စစ်ဆေးခြင်း (Automated Testing)

Backend functionality အားလုံး မှန်ကန်စွာ အလုပ်လုပ်ခြင်း ရှိမရှိ စစ်ဆေးရန်:
```bash
venv\Scripts\activate
pytest test_backend.py -v
```
