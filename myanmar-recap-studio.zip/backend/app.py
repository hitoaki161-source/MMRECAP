"""
Myanmar Recap Studio - Local Windows Backend (FastAPI)
Supports faster-whisper (CPU/GPU), Edge TTS (my-MM-NilarNeural / my-MM-ThihaNeural),
FFmpeg audio extraction, and task queue with progress polling.
"""

import os
import sys
import uuid
import time
import shutil
import asyncio
import subprocess
from pathlib import Path
from typing import Optional, Dict, Any

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

app = FastAPI(title="Myanmar Recap Studio Local Backend", version="1.0.0")

# Allow CORS for local web interface
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Paths
BASE_DIR = Path(__file__).resolve().parent
TEMP_DIR = BASE_DIR / "temp"
UPLOADS_DIR = TEMP_DIR / "uploads"
AUDIO_DIR = TEMP_DIR / "audio"
OUTPUTS_DIR = TEMP_DIR / "outputs"

for d in [UPLOADS_DIR, AUDIO_DIR, OUTPUTS_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# In-memory background jobs registry
jobs: Dict[str, Dict[str, Any]] = {}

# Whisper model cache
whisper_model = None
WHISPER_MODEL_SIZE = os.environ.get("WHISPER_MODEL_SIZE", "base")
WHISPER_DEVICE = os.environ.get("WHISPER_DEVICE", "cpu")
WHISPER_COMPUTE_TYPE = "float32" if WHISPER_DEVICE == "cpu" else "float16"

def get_whisper():
    global whisper_model
    if whisper_model is None:
        try:
            from faster_whisper import WhisperModel
            print(f"[Whisper] Loading model '{WHISPER_MODEL_SIZE}' on device '{WHISPER_DEVICE}'...")
            whisper_model = WhisperModel(WHISPER_MODEL_SIZE, device=WHISPER_DEVICE, compute_type=WHISPER_COMPUTE_TYPE)
            print("[Whisper] Model loaded successfully.")
        except Exception as e:
            print(f"[Whisper] Error loading faster-whisper: {e}")
            raise
    return whisper_model

def check_ffmpeg() -> bool:
    ffmpeg_bin = shutil.which("ffmpeg") or os.environ.get("FFMPEG_PATH")
    if ffmpeg_bin:
        return True
    local_ffmpeg = BASE_DIR / "ffmpeg" / "bin" / "ffmpeg.exe"
    return local_ffmpeg.exists()

def get_ffmpeg_cmd() -> str:
    if shutil.which("ffmpeg"):
        return "ffmpeg"
    local_ffmpeg = BASE_DIR / "ffmpeg" / "bin" / "ffmpeg.exe"
    if local_ffmpeg.exists():
        return str(local_ffmpeg)
    return "ffmpeg"

@app.get("/api/health")
async def health_check():
    ffmpeg_ok = check_ffmpeg()
    whisper_installed = False
    try:
        import faster_whisper
        whisper_installed = True
    except ImportError:
        whisper_installed = False

    edge_tts_installed = False
    try:
        import edge_tts
        edge_tts_installed = True
    except ImportError:
        edge_tts_installed = False

    return {
        "status": "healthy" if (ffmpeg_ok and edge_tts_installed) else "degraded",
        "ffmpegAvailable": ffmpeg_ok,
        "whisperAvailable": whisper_installed,
        "ttsAvailable": edge_tts_installed,
        "aiAvailable": bool(os.environ.get("GEMINI_API_KEY")),
        "activeBackend": "local",
        "whisperConfig": {
            "modelSize": WHISPER_MODEL_SIZE,
            "device": WHISPER_DEVICE,
        },
        "pythonVersion": sys.version.split(" ")[0],
    }

@app.get("/api/jobs/{job_id}")
async def get_job_status(job_id: str):
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job

@app.post("/api/upload")
async def upload_video(video: UploadFile = File(...)):
    allowed_exts = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".mp3", ".wav", ".m4a"}
    ext = Path(video.filename).suffix.lower()
    if ext not in allowed_exts:
        raise HTTPException(
            status_code=415,
            detail=f"မထောက်ပံ့သော ဖိုင်အမျိုးအစားဖြစ်ပါသည် (Unsupported format: {ext}). Please use MP4, MOV, MKV, or WebM.",
        )

    file_id = f"{int(time.time())}_{uuid.uuid4().hex[:6]}"
    safe_name = f"{file_id}_{Path(video.filename).name.replace(' ', '_')}"
    dest_path = UPLOADS_DIR / safe_name

    try:
        with open(dest_path, "wb") as buffer:
            shutil.copyfileobj(video.file, buffer)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save video: {str(e)}")

    file_size = dest_path.stat().st_size

    return {
        "success": True,
        "filename": safe_name,
        "originalName": video.filename,
        "size": file_size,
        "mimeType": video.content_type,
        "hasAudio": True,
        "videoUrl": f"/api/files/video/{safe_name}",
    }

@app.get("/api/files/video/{filename}")
async def stream_video(filename: str):
    file_path = UPLOADS_DIR / Path(filename).name
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Video file not found")
    return FileResponse(file_path, media_type="video/mp4")

class TranscribeRequest(BaseModel):
    filename: Optional[str] = None
    fileName: Optional[str] = None
    file: Optional[str] = None
    sourceLanguage: Optional[str] = "auto"
    modelSize: Optional[str] = None

def run_transcription_task(job_id: str, filename: str, source_lang: str, model_size: Optional[str]):
    video_path = UPLOADS_DIR / Path(filename).name
    audio_path = AUDIO_DIR / f"{Path(filename).stem}_{int(time.time())}.mp3"
    ffmpeg_bin = get_ffmpeg_cmd()

    try:
        jobs[job_id]["status"] = "processing"
        jobs[job_id]["progress"] = 15
        jobs[job_id]["statusMessageBurmese"] = "ဗီဒီယိုမှ အသံဖိုင်အား FFmpeg ဖြင့် ခွဲထုတ်နေပါသည်..."
        jobs[job_id]["statusMessageEnglish"] = "Extracting audio track via FFmpeg..."

        # Extract 16kHz mono audio
        extract_cmd = [
            ffmpeg_bin, "-y", "-i", str(video_path),
            "-vn", "-acodec", "libmp3lame", "-ar", "16000", "-ac", "1", "-b:a", "64k",
            str(audio_path)
        ]
        res = subprocess.run(extract_cmd, capture_output=True, text=True)
        if res.returncode != 0 or not audio_path.exists() or audio_path.stat().st_size == 0:
            raise RuntimeError(f"FFmpeg audio extraction failed: {res.stderr}")

        jobs[job_id]["progress"] = 35
        jobs[job_id]["statusMessageBurmese"] = "faster-whisper ဖြင့် စကားပြောအသံကို စာသားပြောင်းနေပါသည်..."
        jobs[job_id]["statusMessageEnglish"] = "Running faster-whisper speech recognition..."

        model = get_whisper()
        lang_arg = None if source_lang == "auto" else source_lang

        segments_gen, info = model.transcribe(
            str(audio_path),
            language=lang_arg,
            beam_size=5,
            vad_filter=True,
        )

        segments = []
        full_text_parts = []
        srt_lines = []

        for idx, segment in enumerate(segments_gen):
            start_str = format_seconds_to_srt(segment.start)
            end_str = format_seconds_to_srt(segment.end)
            text_clean = segment.text.strip()
            if not text_clean:
                continue

            segments.append({
                "id": idx + 1,
                "start": start_str,
                "end": end_str,
                "text": text_clean,
            })
            full_text_parts.append(text_clean)
            srt_lines.append(f"{idx + 1}\n{start_str} --> {end_str}\n{text_clean}\n")

            # Update progress smoothly
            if idx % 5 == 0:
                jobs[job_id]["progress"] = min(90, 35 + idx)

        full_text = "\n\n".join(full_text_parts)
        srt_content = "\n".join(srt_lines)

        jobs[job_id]["status"] = "completed"
        jobs[job_id]["progress"] = 100
        jobs[job_id]["statusMessageBurmese"] = "အသံမှ စာသားဖော်ယူခြင်း အောင်မြင်ပါသည်"
        jobs[job_id]["statusMessageEnglish"] = "Transcription completed"
        jobs[job_id]["result"] = {
            "fullText": full_text,
            "detectedLanguage": info.language if info else "Detected",
            "segments": segments,
            "srtContent": srt_content,
        }

    except Exception as e:
        jobs[job_id]["status"] = "failed"
        jobs[job_id]["progress"] = 100
        jobs[job_id]["statusMessageBurmese"] = f"စာသားဖော်ယူမှု မအောင်မြင်ပါ: {str(e)}"
        jobs[job_id]["statusMessageEnglish"] = f"Transcription failed: {str(e)}"
        jobs[job_id]["error"] = str(e)

@app.post("/api/transcribe")
async def start_transcription(req: TranscribeRequest, background_tasks: BackgroundTasks):
    target_filename = req.filename or req.fileName or req.file
    if not target_filename or not target_filename.strip():
        raise HTTPException(status_code=400, detail="Filename is required")

    safe_name = Path(target_filename.strip()).name
    video_path = UPLOADS_DIR / safe_name
    if not video_path.exists():
        raise HTTPException(status_code=404, detail=f"Uploaded video file '{safe_name}' not found on server")

    job_id = f"job_transcribe_{int(time.time())}_{uuid.uuid4().hex[:6]}"
    jobs[job_id] = {
        "id": job_id,
        "type": "transcribe",
        "status": "pending",
        "progress": 0,
        "statusMessageBurmese": "စာသားဖော်ယူရန် စတင်ပြင်ဆင်နေပါသည်...",
        "statusMessageEnglish": "Preparing transcription...",
        "createdAt": time.time(),
    }

    background_tasks.add_task(
        run_transcription_task,
        job_id,
        safe_name,
        req.sourceLanguage or "auto",
        req.modelSize,
    )

    return {"jobId": job_id, "message": "Transcription job queued"}

class TranslateRequest(BaseModel):
    originalText: str
    style: Optional[str] = "recap"
    tone: Optional[str] = "dramatic"
    keepTimestamps: Optional[bool] = False

@app.post("/api/translate")
async def translate_to_burmese(req: TranslateRequest):
    if not req.originalText.strip():
        raise HTTPException(status_code=400, detail="Original transcript text is empty")

    api_key = os.environ.get("GEMINI_API_KEY")
    if api_key:
        try:
            import google.genai as genai
            ai = genai.Client(api_key=api_key)
            prompt = f"""You are a professional Myanmar movie recap narrator (မြန်မာ ရုပ်ရှင် Recap အသံသွင်း ဖန်တီးသူ).
Translate and adapt the following original transcript into natural, conversational, dramatic Burmese Unicode suitable for movie recap narration:

Original Text:
{req.originalText}

Requirements:
- Use standard Myanmar Unicode.
- Tone: {req.tone}. Style: {req.style}.
- Use engaging recap storytelling (e.g. "ဒီဇာတ်ကားမှာတော့...", "ဇာတ်လမ်းအစမှာတော့...", "ဒါပေမယ့်...").
- Separate into natural paragraphs for speech pacing."""
            res = ai.models.generate_content(
                model="gemini-3.8-flash",
                contents=prompt,
            )
            return {
                "burmeseText": res.text.strip(),
                "style": req.style,
            }
        except Exception as e:
            print(f"[Gemini fallback] {e}")

    # Local fallback recap formatter
    paragraphs = [p.strip() for p in req.originalText.split("\n") if p.strip()]
    burmese_lines = []
    for i, p in enumerate(paragraphs):
        prefix = "ဒီဇာတ်ကားမှာတော့ " if i == 0 else "အဲဒီနောက်မှာတော့ "
        burmese_lines.append(f"{prefix}{p}")

    return {
        "burmeseText": "\n\n".join(burmese_lines),
        "style": req.style,
        "notice": "Formatted via local recap processor. Add GEMINI_API_KEY for full AI translation.",
    }

class TTSRequest(BaseModel):
    text: str
    voiceId: Optional[str] = "my-MM-NilarNeural"
    rate: Optional[str] = "+0%"
    pitch: Optional[str] = "+0Hz"

async def generate_edge_tts_file(text: str, voice: str, rate: str, pitch: str, output_path: str):
    import edge_tts
    communicate = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    await communicate.save(output_path)

def run_tts_task(job_id: str, text: str, voice_id: str, rate: str, pitch: str):
    try:
        jobs[job_id]["status"] = "processing"
        jobs[job_id]["progress"] = 25
        jobs[job_id]["statusMessageBurmese"] = f"Edge TTS ({voice_id}) ဖြင့် မြန်မာအသံဖိုင် ဖန်တီးနေပါသည်..."
        jobs[job_id]["statusMessageEnglish"] = f"Generating Myanmar voice audio with Edge TTS ({voice_id})..."

        # Split text into chunks
        sentences = [s.strip() for s in text.replace("\r", "").split("\n") if s.strip()]
        if not sentences:
            sentences = [text]

        session_id = f"tts_{int(time.time())}_{uuid.uuid4().hex[:6]}"
        session_dir = AUDIO_DIR / session_id
        session_dir.mkdir(parents=True, exist_ok=True)

        part_paths = []
        for idx, sentence in enumerate(sentences):
            chunk_file = session_dir / f"chunk_{idx:03d}.mp3"
            asyncio.run(generate_edge_tts_file(sentence, voice_id, rate, pitch, str(chunk_file)))
            part_paths.append(str(chunk_file))
            jobs[job_id]["progress"] = min(80, 25 + int((idx + 1) / len(sentences) * 55))

        ffmpeg_bin = get_ffmpeg_cmd()
        audio_id = f"recap_voice_{int(time.time())}"
        final_mp3 = OUTPUTS_DIR / f"{audio_id}.mp3"
        final_wav = OUTPUTS_DIR / f"{audio_id}.wav"

        if len(part_paths) == 1:
            shutil.copyfile(part_paths[0], str(final_mp3))
        else:
            concat_file = session_dir / "concat.txt"
            with open(concat_file, "w", encoding="utf-8") as f:
                for p in part_paths:
                    f.write(f"file '{p}'\n")
            merge_cmd = [ffmpeg_bin, "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file), "-c", "copy", str(final_mp3)]
            subprocess.run(merge_cmd, check=True)

        # Convert to WAV
        wav_cmd = [ffmpeg_bin, "-y", "-i", str(final_mp3), "-acodec", "pcm_s16le", "-ar", "24000", "-ac", "1", str(final_wav)]
        subprocess.run(wav_cmd, check=True)

        shutil.rmtree(session_dir, ignore_errors=True)

        jobs[job_id]["status"] = "completed"
        jobs[job_id]["progress"] = 100
        jobs[job_id]["statusMessageBurmese"] = "မြန်မာ အသံဇာတ်ကြောင်းပြော ဖိုင် ဖန်တီးပြီးပါပြီ"
        jobs[job_id]["statusMessageEnglish"] = "Myanmar voice narration ready"
        jobs[job_id]["result"] = {
            "audioId": audio_id,
            "mp3Url": f"/api/files/audio/{audio_id}.mp3",
            "wavUrl": f"/api/files/audio/{audio_id}.wav",
            "voiceUsed": voice_id,
            "fileSizeBytes": final_mp3.stat().st_size,
        }

    except Exception as e:
        jobs[job_id]["status"] = "failed"
        jobs[job_id]["progress"] = 100
        jobs[job_id]["statusMessageBurmese"] = f"အသံဖန်တီးမှု မအောင်မြင်ပါ: {str(e)}"
        jobs[job_id]["statusMessageEnglish"] = f"Voice generation failed: {str(e)}"
        jobs[job_id]["error"] = str(e)

@app.post("/api/tts")
async def start_tts(req: TTSRequest, background_tasks: BackgroundTasks):
    if not req.text.strip():
        raise HTTPException(status_code=400, detail="Myanmar text is required for TTS")

    job_id = f"job_tts_{int(time.time())}_{uuid.uuid4().hex[:6]}"
    jobs[job_id] = {
        "id": job_id,
        "type": "tts",
        "status": "pending",
        "progress": 0,
        "statusMessageBurmese": "အသံဖိုင် စတင်ဖန်တီးရန် ပြင်ဆင်နေပါသည်...",
        "statusMessageEnglish": "Preparing audio synthesis...",
        "createdAt": time.time(),
    }

    background_tasks.add_task(
        run_tts_task,
        job_id,
        req.text,
        req.voiceId or "my-MM-NilarNeural",
        req.rate or "+0%",
        req.pitch or "+0Hz",
    )

    return {"jobId": job_id, "message": "TTS job queued"}

@app.get("/api/files/audio/{filename}")
async def stream_audio(filename: str):
    file_path = OUTPUTS_DIR / Path(filename).name
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Audio file not found")
    media_type = "audio/wav" if file_path.suffix == ".wav" else "audio/mpeg"
    return FileResponse(file_path, media_type=media_type)

@app.get("/api/download/{file_type}/{file_id}")
async def download_file(file_type: str, file_id: str):
    safe_id = Path(file_id).name
    if file_type == "audio-mp3":
        f = OUTPUTS_DIR / f"{safe_id}.mp3"
        if f.exists():
            return FileResponse(f, filename=f"Myanmar_Recap_Voice_{safe_id}.mp3", media_type="audio/mpeg")
    elif file_type == "audio-wav":
        f = OUTPUTS_DIR / f"{safe_id}.wav"
        if f.exists():
            return FileResponse(f, filename=f"Myanmar_Recap_Voice_{safe_id}.wav", media_type="audio/wav")

    raise HTTPException(status_code=404, detail="File not found or expired")

def format_seconds_to_srt(seconds: float) -> str:
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int((seconds % 1) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=7860, reload=True)
