@echo off
chcp 65001 >nul
title FFmpeg Setup for Windows 10/11 - Myanmar Recap Studio

echo =====================================================================
echo           FFmpeg Auto-Setup for Myanmar Recap Studio
echo =====================================================================
echo.

ffmpeg -version >nul 2>&1
if %errorlevel% equ 0 (
    echo [✓] FFmpeg is already installed and available in your Windows PATH!
    ffmpeg -version | findstr /i "version"
    echo.
    pause
    exit /b 0
)

echo [*] FFmpeg ကို ရှာမတွေ့သေးပါ။ အလိုအလျောက် သွင်းယူရန် ပြင်ဆင်နေပါသည်...
echo [*] Downloading FFmpeg essentials release...

set "FFMPEG_DIR=%~dp0ffmpeg"
if not exist "%FFMPEG_DIR%" mkdir "%FFMPEG_DIR%"

powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Write-Host 'Downloading ffmpeg-release-essentials.zip...'; Invoke-WebRequest -Uri 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip' -OutFile '%FFMPEG_DIR%\ffmpeg.zip'"

if not exist "%FFMPEG_DIR%\ffmpeg.zip" (
    echo [ERROR] FFmpeg download failed. Please manually install FFmpeg or use winget:
    echo        winget install Gyan.FFmpeg
    echo.
    pause
    exit /b 1
)

echo [*] Extracting FFmpeg...
powershell -Command "Expand-Archive -Path '%FFMPEG_DIR%\ffmpeg.zip' -DestinationPath '%FFMPEG_DIR%' -Force"

:: Move contents to bin
for /d %%D in ("%FFMPEG_DIR%\ffmpeg-*") do (
    xcopy /E /I /Y "%%D\bin" "%FFMPEG_DIR%\bin"
    xcopy /E /I /Y "%%D\doc" "%FFMPEG_DIR%\doc"
)

del "%FFMPEG_DIR%\ffmpeg.zip"

echo.
echo =====================================================================
echo [✓] FFmpeg installation completed successfully!
echo Path: %FFMPEG_DIR%\bin\ffmpeg.exe
echo =====================================================================
echo.
pause
