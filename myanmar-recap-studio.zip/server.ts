import http from 'http';
import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { exec, spawn } from 'child_process';
import { promisify } from 'util';
import dotenv from 'dotenv';
import { MsEdgeTTS, OUTPUT_FORMAT } from 'msedge-tts';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const execAsync = promisify(exec);
const app = express();
// Port 3000 is required by the development environment
const PORT = 3000;

console.log('[Myanmar Recap Studio] Server initializing...');
console.log(`[Myanmar Recap Studio] Environment: NODE_ENV=${process.env.NODE_ENV || 'development'}, PORT=${PORT}`);
if (process.env.GEMINI_API_KEY) {
  console.log('[Myanmar Recap Studio] Gemini API Key detected for server-side processing.');
} else {
  console.warn('[Myanmar Recap Studio] Notice: GEMINI_API_KEY is not defined. Transcription and translation will prompt for API key.');
}

// Directories
const UPLOAD_DIR = path.resolve('/tmp/recap_studio/uploads');
const AUDIO_DIR = path.resolve('/tmp/recap_studio/audio');
const OUTPUT_DIR = path.resolve('/tmp/recap_studio/outputs');

for (const dir of [UPLOAD_DIR, AUDIO_DIR, OUTPUT_DIR]) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

// Memory Job Store
interface JobData {
  id: string;
  type: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  statusMessageBurmese: string;
  statusMessageEnglish: string;
  result?: any;
  error?: string;
  createdAt: number;
}
const jobs = new Map<string, JobData>();

function createJob(type: string, initialMsgBurmese: string, initialMsgEnglish: string): string {
  const id = `job_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  jobs.set(id, {
    id,
    type,
    status: 'pending',
    progress: 0,
    statusMessageBurmese: initialMsgBurmese,
    statusMessageEnglish: initialMsgEnglish,
    createdAt: Date.now(),
  });
  return id;
}

function updateJob(id: string, update: Partial<JobData>) {
  const job = jobs.get(id);
  if (job) {
    jobs.set(id, { ...job, ...update });
  }
}

// Gemini AI Client Setup
let geminiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  geminiClient = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Multer Storage Configuration
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOAD_DIR);
  },
  filename: (_req, file, cb) => {
    // Sanitize filename to prevent directory traversal
    const safeBase = path.basename(file.originalname).replace(/[^a-zA-Z0-9._-]/g, '_');
    const uniqueSuffix = `${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    cb(null, `${uniqueSuffix}_${safeBase}`);
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: 500 * 1024 * 1024, // 500MB max limit
  },
  fileFilter: (_req, file, cb) => {
    const allowedExtensions = ['.mp4', '.mov', '.mkv', '.webm', '.avi', '.mp3', '.wav', '.m4a', '.aac'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedExtensions.includes(ext) || file.mimetype.startsWith('video/') || file.mimetype.startsWith('audio/')) {
      cb(null, true);
    } else {
      cb(new Error(`မထောက်ပံ့သော ဖိုင်အမျိုးအစားဖြစ်ပါသည် (Unsupported format: ${ext}). Please upload MP4, MOV, MKV, or WebM.`));
    }
  },
});

// Periodic cleanup of temp files older than 2 hours
setInterval(() => {
  const now = Date.now();
  const maxAgeMs = 2 * 60 * 60 * 1000;
  for (const dir of [UPLOAD_DIR, AUDIO_DIR, OUTPUT_DIR]) {
    try {
      if (fs.existsSync(dir)) {
        const files = fs.readdirSync(dir);
        for (const file of files) {
          const filePath = path.join(dir, file);
          const stats = fs.statSync(filePath);
          if (now - stats.mtimeMs > maxAgeMs) {
            fs.unlinkSync(filePath);
          }
        }
      }
    } catch (e) {
      console.error('Cleanup error:', e);
    }
  }

  // Cleanup old jobs
  for (const [id, job] of jobs.entries()) {
    if (now - job.createdAt > maxAgeMs) {
      jobs.delete(id);
    }
  }
}, 15 * 60 * 1000);

// Middleware
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// CORS headers for local/cross-origin requests
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// ----------------------------------------------------
// API ROUTES
// ----------------------------------------------------

/**
 * Health check endpoint
 */
app.get('/api/health', async (_req, res) => {
  let ffmpegAvailable = false;
  let ffmpegVersion = '';
  let ttsAvailable = false;

  try {
    const { stdout } = await execAsync('ffmpeg -version');
    ffmpegAvailable = true;
    ffmpegVersion = stdout.split('\n')[0] || 'Available';
  } catch {
    ffmpegAvailable = false;
  }

  // Quick check if TTS client can initialize
  try {
    const tts = new MsEdgeTTS({ enableLogger: false });
    ttsAvailable = true;
    tts.close();
  } catch {
    ttsAvailable = false;
  }

  const aiAvailable = !!process.env.GEMINI_API_KEY;

  res.json({
    status: ffmpegAvailable ? 'healthy' : 'degraded',
    ffmpegAvailable,
    ffmpegVersion,
    ttsAvailable,
    aiAvailable,
    activeBackend: 'cloud',
    tempStorage: {
      uploads: fs.existsSync(UPLOAD_DIR),
      audio: fs.existsSync(AUDIO_DIR),
      outputs: fs.existsSync(OUTPUT_DIR),
    },
  });
});

/**
 * Job status checking endpoint
 */
app.get('/api/jobs/:id', (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) {
    return res.status(404).json({ error: 'Job not found' });
  }
  res.json(job);
});

/**
 * Video upload endpoint
 */
app.post('/api/upload', (req, res) => {
  upload.single('video')(req, res, async (err) => {
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(413).json({
          error: 'ဖိုင်အရွယ်အစား ကြီးလွန်းပါသည် (အများဆုံး 500MB သာ ခွင့်ပြုပါသည်). File too large (max 500MB).',
        });
      }
      return res.status(400).json({ error: err.message || 'File upload failed' });
    }

    if (!req.file) {
      return res.status(400).json({ error: 'ဗီဒီယိုဖိုင် ရွေးချယ်ပေးပါ (Please select a video file).' });
    }

    const uploadedPath = req.file.path;
    const originalName = req.file.originalname;
    const fileSize = req.file.size;

    // Check FFmpeg availability and probe video
    try {
      const probeCmd = `ffprobe -v error -show_entries stream=codec_type,duration -of default=noprint_wrappers=1:nokey=1 "${uploadedPath}"`;
      const { stdout: probeOut } = await execAsync(probeCmd);
      const streams = probeOut.split('\n').filter(Boolean);
      const hasAudio = streams.some((s) => s.trim() === 'audio');

      res.json({
        success: true,
        filename: path.basename(uploadedPath),
        originalName,
        size: fileSize,
        mimeType: req.file.mimetype,
        hasAudio,
        videoUrl: `/api/files/video/${path.basename(uploadedPath)}`,
      });
    } catch (probeErr: any) {
      // If ffprobe is missing or file has issue, check if ffmpeg can at least read it
      console.warn('Probe notice:', probeErr?.message);
      res.json({
        success: true,
        filename: path.basename(uploadedPath),
        originalName,
        size: fileSize,
        mimeType: req.file.mimetype,
        hasAudio: true, // Assume true so backend can attempt extraction
        videoUrl: `/api/files/video/${path.basename(uploadedPath)}`,
      });
    }
  });
});

/**
 * Serve uploaded video for browser preview (if supported by browser)
 */
app.get('/api/files/video/:filename', (req, res) => {
  const safeFilename = path.basename(req.params.filename);
  const filePath = path.join(UPLOAD_DIR, safeFilename);

  if (!fs.existsSync(filePath)) {
    return res.status(404).send('File not found');
  }

  const stat = fs.statSync(filePath);
  const fileSize = stat.size;
  const range = req.headers.range;

  if (range) {
    const parts = range.replace(/bytes=/, '').split('-');
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
    const chunksize = end - start + 1;
    const file = fs.createReadStream(filePath, { start, end });
    const head = {
      'Content-Range': `bytes ${start}-${end}/${fileSize}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunksize,
      'Content-Type': 'video/mp4',
    };
    res.writeHead(206, head);
    file.pipe(res);
  } else {
    const head = {
      'Content-Length': fileSize,
      'Content-Type': 'video/mp4',
    };
    res.writeHead(200, head);
    fs.createReadStream(filePath).pipe(res);
  }
});

/**
 * Transcribe Video Dialogue:
 * 1. Extract audio via FFmpeg
 * 2. Transcribe via Gemini 3.5 Transcribe
 * 3. Generate timestamps and paragraph breaks
 */
app.post('/api/transcribe', async (req, res) => {
  const rawFilename = (
    req.body.filename ||
    req.body.fileName ||
    req.body.file ||
    req.body.videoFilename ||
    (typeof req.body.video === 'string' ? req.body.video : req.body.video?.filename) ||
    (req.body.videoUrl ? path.basename(req.body.videoUrl) : undefined)
  );

  const sourceLanguage = req.body.sourceLanguage || 'auto';

  if (!rawFilename || typeof rawFilename !== 'string' || !rawFilename.trim()) {
    return res.status(400).json({
      error: 'Filename is required. Please upload a video file first.',
      detail: 'The transcription request did not include a valid video filename.',
    });
  }

  const safeFilename = path.basename(rawFilename.trim());
  const videoPath = path.join(UPLOAD_DIR, safeFilename);
  if (!fs.existsSync(videoPath)) {
    return res.status(404).json({
      error: `ဗီဒီယိုဖိုင် '${safeFilename}' မတွေ့ရှိပါ (Uploaded video not found on server). Please re-upload your video.`,
      filename: safeFilename,
    });
  }

  const jobId = createJob('transcribe', 'ဗီဒီယိုမှ အသံဖိုင် စတင်ခွဲထုတ်နေပါသည်...', 'Extracting audio from video...');
  res.json({ jobId, message: 'Transcription job started' });

  // Process asynchronously in background
  (async () => {
    const audioFilename = `audio_${Date.now()}_${path.basename(safeFilename, path.extname(safeFilename))}.mp3`;
    const audioPath = path.join(AUDIO_DIR, audioFilename);

    try {
      updateJob(jobId, {
        status: 'processing',
        progress: 20,
        statusMessageBurmese: 'ဗီဒီယိုမှ အသံဖိုင် (Audio Track) အား FFmpeg ဖြင့် ခွဲထုတ်နေပါသည်...',
        statusMessageEnglish: 'Extracting audio track via FFmpeg...',
      });

      // Extract 16kHz mono MP3 for optimal Whisper/AI processing
      const extractCmd = `ffmpeg -y -i "${videoPath}" -vn -acodec libmp3lame -ar 16000 -ac 1 -b:a 64k "${audioPath}"`;
      await execAsync(extractCmd);

      if (!fs.existsSync(audioPath) || fs.statSync(audioPath).size === 0) {
        throw new Error('ဗီဒီယိုဖိုင်တွင် အသံဖိုင် (Audio) မပါဝင်ပါ သို့မဟုတ် FFmpeg အသံခွဲထုတ်မှု မအောင်မြင်ပါ (No audio stream extracted)');
      }

      updateJob(jobId, {
        progress: 50,
        statusMessageBurmese: 'စကားပြောအသံကို စာသားအဖြစ် အသိအမှတ်ပြု မှတ်သားနေပါသည် (Whisper/AI Speech-to-Text)...',
        statusMessageEnglish: 'Transcribing speech to text with timestamps...',
      });

      // Check audio size
      const audioBuffer = fs.readFileSync(audioPath);
      const audioBase64 = audioBuffer.toString('base64');

      if (!geminiClient) {
        throw new Error('GEMINI_API_KEY is not configured on the server. Please check your environment configuration.');
      }

      const langPrompt =
        sourceLanguage === 'auto'
          ? 'Automatically detect the spoken source language.'
          : `The spoken dialogue language is predominantly ${sourceLanguage}.`;

      const prompt = `You are an expert audio transcription system.
${langPrompt}
Transcribe all the spoken dialogue and narrative speech from this audio file accurately.
Do not omit plot dialogue or character speech.

Return your response in clean JSON format matching this structure:
{
  "detectedLanguage": "English",
  "fullText": "Full transcript with proper paragraph breaks separated by double newlines...",
  "segments": [
    {
      "id": 1,
      "start": "00:00:01",
      "end": "00:00:05",
      "speaker": "Speaker 1",
      "text": "Exact spoken line"
    }
  ]
}

Formatting requirements:
1. Ensure fullText has clear paragraph breaks reflecting natural movie scene transitions.
2. Provide realistic timestamps for segments based on the audio timeline.
3. Keep character names and plot-critical dialogue intact.`;

      const aiResponse = await geminiClient.models.generateContent({
        model: 'gemini-3.5-transcribe',
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: 'audio/mp3',
                data: audioBase64,
              },
            },
            { text: prompt },
          ],
        },
      });

      // Probe audio duration for timestamp calculation
      let audioDuration = 0;
      try {
        const { stdout: durOut } = await execAsync(`ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${audioPath}"`);
        audioDuration = parseFloat(durOut) || 0;
      } catch {
        audioDuration = 0;
      }

      // Safely extract text across all candidate content parts to handle text and audioTranscription parts
      let rawText = '';
      const parts = aiResponse.candidates?.[0]?.content?.parts;
      if (Array.isArray(parts)) {
        for (const part of parts) {
          if (part && typeof part.text === 'string') {
            rawText += part.text;
          } else if (part && (part as any).audioTranscription && typeof (part as any).audioTranscription.text === 'string') {
            rawText += (part as any).audioTranscription.text;
          }
        }
      }
      if (!rawText && typeof aiResponse.text === 'string') {
        rawText = aiResponse.text;
      }
      const responseText = rawText.trim();

      if (!responseText) {
        throw new Error('ဗီဒီယိုဖိုင်မှ စကားပြောသံ မတွေ့ရှိပါ သို့မဟုတ် အသံတိတ်ဆိတ်နေပါသည် (No dialogue or speech detected in the audio track of this video).');
      }

      let fullText = '';
      let detectedLanguage = sourceLanguage !== 'auto' ? sourceLanguage : 'Detected';
      let segments: any[] = [];

      try {
        const jsonMatch = responseText.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0]);
          fullText = parsed.fullText || '';
          if (parsed.detectedLanguage) detectedLanguage = parsed.detectedLanguage;
          segments = Array.isArray(parsed.segments) ? parsed.segments : [];
        } else {
          fullText = responseText;
        }
      } catch {
        fullText = responseText;
      }

      if (!fullText) {
        fullText = responseText;
      }

      // If segments were not produced in JSON, split into natural sentences/paragraphs
      if (segments.length === 0 && fullText) {
        // Split by sentences or line breaks while preserving meaning
        const lines = fullText
          .replace(/([.?!])\s+/g, '$1\n')
          .split(/\n+/)
          .map((s) => s.trim())
          .filter(Boolean);

        const count = Math.max(1, lines.length);
        const segmentDuration = audioDuration > 0 ? audioDuration / count : 4.5;

        segments = lines.map((line, idx) => {
          const startSec = idx * segmentDuration;
          const endSec = audioDuration > 0
            ? Math.min(startSec + segmentDuration * 0.95, audioDuration)
            : startSec + 4.0;

          return {
            id: idx + 1,
            start: formatSecondsToTimestamp(startSec),
            end: formatSecondsToTimestamp(endSec),
            speaker: `Speaker 1`,
            text: line,
          };
        });
      }

      // Build SRT subtitle string
      let srtContent = '';
      segments.forEach((seg: any, idx: number) => {
        const start = formatTimestampToSrt(seg.start || '00:00:00');
        const end = formatTimestampToSrt(seg.end || '00:00:05');
        srtContent += `${idx + 1}\n${start} --> ${end}\n${seg.text}\n\n`;
      });

      updateJob(jobId, {
        status: 'completed',
        progress: 100,
        statusMessageBurmese: 'အသံမှ စာသားဖော်ယူခြင်း အောင်မြင်ပါသည် (Transcription Completed)',
        statusMessageEnglish: 'Transcription completed successfully',
        result: {
          fullText,
          detectedLanguage: detectedLanguage || 'Detected',
          segments,
          srtContent,
        },
      });
    } catch (err: any) {
      console.error('Transcription error:', err);
      updateJob(jobId, {
        status: 'failed',
        progress: 100,
        statusMessageBurmese: `စာသားဖော်ယူမှု မအောင်မြင်ပါ: ${err.message || 'Error'}`,
        statusMessageEnglish: `Transcription failed: ${err.message || 'Error'}`,
        error: err.message || 'Transcription failed',
      });
    }
  })();
});

/**
 * Translate & Adapt to Natural Myanmar Movie Recap Narration
 */
app.post('/api/translate', async (req, res) => {
  const { originalText, style = 'recap', tone = 'dramatic', keepTimestamps = false } = req.body;

  if (!originalText || !originalText.trim()) {
    return res.status(400).json({ error: 'Original transcript text is required.' });
  }

  if (!geminiClient) {
    return res.status(500).json({ error: 'GEMINI_API_KEY is not configured on the server.' });
  }

  const jobId = createJob('translate', 'မြန်မာဘာသာ ရုပ်ရှင် Recap အဖြစ် ပြောင်းလဲနေပါသည်...', 'Adapting to Myanmar movie recap narration...');
  res.json({ jobId, message: 'Translation job started' });

  (async () => {
    try {
      updateJob(jobId, {
        status: 'processing',
        progress: 30,
        statusMessageBurmese: 'မြန်မာ ယူနီကုဒ်ဖြင့် သဘာဝကျသော ရုပ်ရှင် Recap ဇာတ်ကြောင်းပြော ပုံစံသို့ ဘာသာပြန်နေပါသည်...',
        statusMessageEnglish: 'Translating into natural conversational Burmese recap narration...',
      });

      const styleGuide =
        style === 'recap'
          ? `Format as a captivating, dramatic, and engaging YouTube movie recap narration in Burmese (မြန်မာ ရုပ်ရှင် Recap ဇာတ်ကြောင်းပြော စတိုင်).
Use natural spoken storytelling phrases such as "ဒီဇာတ်ကားမှာတော့...", "ဇာတ်လမ်းအစမှာတော့...", "ဒါပေမယ့် မမျှော်လင့်ဘဲ...", "အဲဒီနောက်မှာတော့...".
Make the audience hooked and entertained. Maintain dramatic tension and clear flow.`
          : style === 'dialogue'
          ? `Translate accurately into natural spoken Burmese dialogue suitable for subtitles and character voiceovers. Keep colloquial conversational Burmese rather than formal written grammar.`
          : `Create a concise, punchy movie recap summary in engaging Burmese narration.`;

      const prompt = `You are a professional Myanmar movie recap creator and voice narrator (မြန်မာ ရုပ်ရှင် Recap အသံသွင်း ဖန်တီးသူ).
Your task is to translate and adapt the following original movie transcript into high-quality Myanmar (Burmese) Unicode text suitable for movie recap narration.

Style Instructions:
${styleGuide}

Key Rules:
1. Output MUST use standard Myanmar Unicode (မြန်မာ ယူနီကုဒ်). Do NOT use Zawgyi.
2. Never silently discard character names, plot points, or sequence of events.
3. Tone: ${tone}.
4. Divide the narration into well-paced paragraphs with double line breaks so that voice actors and TTS engines can pace it comfortably.
5. Do NOT include markdown bold stars inside sentences that would disrupt TTS pronunciation.
6. Write only the Burmese recap narration text ready for text-to-speech.`;

      const aiResponse = await geminiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `${prompt}\n\nOriginal Transcript to adapt:\n${originalText}`,
      });

      let burmeseText = (aiResponse.text || '').trim();
      // Remove markdown formatting stars for clean TTS pronunciation
      burmeseText = burmeseText.replace(/\*\*/g, '');

      updateJob(jobId, {
        status: 'completed',
        progress: 100,
        statusMessageBurmese: 'မြန်မာ ရုပ်ရှင် Recap ဘာသာပြန်ခြင်း အောင်မြင်ပါသည်',
        statusMessageEnglish: 'Myanmar translation and adaptation completed',
        result: {
          burmeseText,
          style,
        },
      });
    } catch (err: any) {
      console.error('Translation error:', err);
      updateJob(jobId, {
        status: 'failed',
        progress: 100,
        statusMessageBurmese: `မြန်မာဘာသာပြန် မအောင်မြင်ပါ: ${err.message}`,
        statusMessageEnglish: `Translation failed: ${err.message}`,
        error: err.message,
      });
    }
  })();
});

/**
 * Myanmar Text-to-Speech via Microsoft Edge TTS
 * Voices: my-MM-NilarNeural (Female), my-MM-ThihaNeural (Male)
 * Chunks long text safely at Burmese sentence breaks ('။', '\n') and merges via FFmpeg.
 */
app.post('/api/tts', async (req, res) => {
  const { text, voiceId = 'my-MM-NilarNeural', rate = '+0%', pitch = '+0Hz' } = req.body;

  if (!text || !text.trim()) {
    return res.status(400).json({ error: 'Myanmar text is required for voice generation.' });
  }

  const jobId = createJob('tts', 'မြန်မာ အသံဖိုင် စတင်ဖန်တီးနေပါသည်...', 'Generating Myanmar voice audio...');
  res.json({ jobId, message: 'TTS job started' });

  (async () => {
    const sessionDir = path.join(AUDIO_DIR, `tts_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`);
    fs.mkdirSync(sessionDir, { recursive: true });

    try {
      updateJob(jobId, {
        status: 'processing',
        progress: 20,
        statusMessageBurmese: `Microsoft Edge TTS (${voiceId === 'my-MM-NilarNeural' ? 'နီလာ - မ' : 'သီဟ - ကျား'}) ဖြင့် အသံဖန်တီးနေပါသည်...`,
        statusMessageEnglish: `Synthesizing audio via Edge TTS (${voiceId})...`,
      });

      // Split text into manageable chunks at sentence breaks
      const chunks = splitBurmeseTextIntoChunks(text, 250);
      const audioParts: string[] = [];

      for (let i = 0; i < chunks.length; i++) {
        const chunk = chunks[i].trim();
        if (!chunk) continue;

        const chunkProgress = 20 + Math.round(((i + 1) / chunks.length) * 50);
        updateJob(jobId, {
          progress: chunkProgress,
          statusMessageBurmese: `အသံအပိုင်း (${i + 1}/${chunks.length}) ကို သွင်းယူနေပါသည်...`,
          statusMessageEnglish: `Synthesizing chunk ${i + 1} of ${chunks.length}...`,
        });

        const chunkDir = path.join(sessionDir, `chunk_${i}`);
        fs.mkdirSync(chunkDir, { recursive: true });

        const tts = new MsEdgeTTS({ enableLogger: false, connectionTimeoutMs: 15000 });
        try {
          await tts.setMetadata(voiceId, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3);
          const chunkRes = await tts.toFile(chunkDir, chunk, {
            rate: rate || '+0%',
            pitch: pitch || '+0Hz',
          });
          audioParts.push(chunkRes.audioFilePath);
        } finally {
          tts.close();
        }
      }

      if (audioParts.length === 0) {
        throw new Error('စာသားမှ အသံဖိုင် မထုတ်လုပ်နိုင်ပါ (Failed to generate audio chunks)');
      }

      updateJob(jobId, {
        progress: 80,
        statusMessageBurmese: 'အသံဖိုင်များကို ပေါင်းစပ်ပြီး အရည်အသွေးမြင့် WAV/MP3 အဖြစ် ပြောင်းလဲနေပါသည်...',
        statusMessageEnglish: 'Merging and converting audio tracks with FFmpeg...',
      });

      const audioId = `recap_voice_${Date.now()}`;
      const finalMp3Path = path.join(OUTPUT_DIR, `${audioId}.mp3`);
      const finalWavPath = path.join(OUTPUT_DIR, `${audioId}.wav`);

      if (audioParts.length === 1) {
        // Copy single file
        fs.copyFileSync(audioParts[0], finalMp3Path);
      } else {
        // Concatenate using FFmpeg concat protocol
        const concatListPath = path.join(sessionDir, 'concat_list.txt');
        const concatContent = audioParts.map((p) => `file '${p.replace(/'/g, "'\\''")}'`).join('\n');
        fs.writeFileSync(concatListPath, concatContent, 'utf8');

        const mergeCmd = `ffmpeg -y -f concat -safe 0 -i "${concatListPath}" -c copy "${finalMp3Path}"`;
        await execAsync(mergeCmd);
      }

      // Generate standard WAV version via FFmpeg as required by Requirement 2D
      const convertWavCmd = `ffmpeg -y -i "${finalMp3Path}" -acodec pcm_s16le -ar 24000 -ac 1 "${finalWavPath}"`;
      await execAsync(convertWavCmd);

      // Probe duration
      let durationSeconds = 0;
      try {
        const durCmd = `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${finalMp3Path}"`;
        const { stdout: durOut } = await execAsync(durCmd);
        durationSeconds = parseFloat(durOut) || 0;
      } catch {
        durationSeconds = 0;
      }

      const fileSizeBytes = fs.statSync(finalMp3Path).size;

      // Clean session temp chunks
      try {
        fs.rmSync(sessionDir, { recursive: true, force: true });
      } catch {}

      updateJob(jobId, {
        status: 'completed',
        progress: 100,
        statusMessageBurmese: 'မြန်မာ အသံဇာတ်ကြောင်းပြော ဖိုင် ဖန်တီးပြီးပါပြီ (Voice Generation Ready)',
        statusMessageEnglish: 'Myanmar voice narration ready',
        result: {
          audioId,
          mp3Url: `/api/files/audio/${audioId}.mp3`,
          wavUrl: `/api/files/audio/${audioId}.wav`,
          durationSeconds,
          voiceUsed: voiceId,
          fileSizeBytes,
        },
      });
    } catch (err: any) {
      console.error('TTS error:', err);
      try {
        fs.rmSync(sessionDir, { recursive: true, force: true });
      } catch {}
      updateJob(jobId, {
        status: 'failed',
        progress: 100,
        statusMessageBurmese: `အသံသွင်းခြင်း မအောင်မြင်ပါ: ${err.message}. Internet ချိတ်ဆက်မှုကို စစ်ဆေးပါ။`,
        statusMessageEnglish: `Voice generation failed: ${err.message}. Edge TTS requires active internet.`,
        error: err.message,
      });
    }
  })();
});

/**
 * Serve generated audio files
 */
app.get('/api/files/audio/:filename', (req, res) => {
  const safeFilename = path.basename(req.params.filename);
  const filePath = path.join(OUTPUT_DIR, safeFilename);

  if (!fs.existsSync(filePath)) {
    return res.status(404).send('Audio file not found');
  }

  const ext = path.extname(safeFilename).toLowerCase();
  const contentType = ext === '.wav' ? 'audio/wav' : 'audio/mpeg';

  res.setHeader('Content-Type', contentType);
  res.setHeader('Accept-Ranges', 'bytes');
  fs.createReadStream(filePath).pipe(res);
});

/**
 * Download endpoint for transcripts (TXT / SRT) and audio (WAV / MP3)
 */
app.get('/api/download/:type/:id', (req, res) => {
  const { type, id } = req.params;
  const safeId = path.basename(id);

  if (type === 'audio-mp3') {
    const file = path.join(OUTPUT_DIR, `${safeId}.mp3`);
    if (fs.existsSync(file)) {
      return res.download(file, `Myanmar_Recap_Voice_${safeId}.mp3`);
    }
  } else if (type === 'audio-wav') {
    const file = path.join(OUTPUT_DIR, `${safeId}.wav`);
    if (fs.existsSync(file)) {
      return res.download(file, `Myanmar_Recap_Voice_${safeId}.wav`);
    }
  }

  res.status(404).send('File not found or expired');
});

// Helper: Format seconds or timestamp to SRT timecode: 00:00:01,000
function formatTimestampToSrt(timeStr: string): string {
  if (timeStr.includes(':')) {
    const parts = timeStr.split(':');
    let hours = '00';
    let mins = '00';
    let secs = '00';
    let ms = '000';

    if (parts.length === 3) {
      hours = parts[0].padStart(2, '0');
      mins = parts[1].padStart(2, '0');
      secs = parts[2].split('.')[0].padStart(2, '0');
      ms = (parts[2].split('.')[1] || '000').padEnd(3, '0').substring(0, 3);
    } else if (parts.length === 2) {
      mins = parts[0].padStart(2, '0');
      secs = parts[1].split('.')[0].padStart(2, '0');
      ms = (parts[1].split('.')[1] || '000').padEnd(3, '0').substring(0, 3);
    }
    return `${hours}:${mins}:${secs},${ms}`;
  }

  const num = parseFloat(timeStr) || 0;
  const h = Math.floor(num / 3600);
  const m = Math.floor((num % 3600) / 60);
  const s = Math.floor(num % 60);
  const ms = Math.floor((num % 1) * 1000);

  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')},${String(ms).padStart(3, '0')}`;
}

// Helper: Format seconds to standard timestamp HH:MM:SS
function formatSecondsToTimestamp(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

// Helper: Split Burmese text by sentence terminators ('။', '\n') preserving natural words
function splitBurmeseTextIntoChunks(text: string, maxChars = 250): string[] {
  const sentences = text
    .split(/(?<=[။\n])/)
    .map((s) => s.trim())
    .filter(Boolean);

  const chunks: string[] = [];
  let currentChunk = '';

  for (const sentence of sentences) {
    if ((currentChunk + ' ' + sentence).length <= maxChars) {
      currentChunk += (currentChunk ? ' ' : '') + sentence;
    } else {
      if (currentChunk) {
        chunks.push(currentChunk);
      }
      if (sentence.length > maxChars) {
        // If single sentence exceeds maxChars, split by comma or words
        const subParts = sentence.split(/(?<=[၊\s])/);
        let subChunk = '';
        for (const part of subParts) {
          if ((subChunk + part).length <= maxChars) {
            subChunk += part;
          } else {
            if (subChunk) chunks.push(subChunk);
            subChunk = part;
          }
        }
        if (subChunk) chunks.push(subChunk);
        currentChunk = '';
      } else {
        currentChunk = sentence;
      }
    }
  }

  if (currentChunk) {
    chunks.push(currentChunk);
  }

  return chunks.length > 0 ? chunks : [text];
}

// ----------------------------------------------------
// Start Server & Mount Vite in Dev Mode
// ----------------------------------------------------
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';
  const httpServer = http.createServer(app);

  if (isDev) {
    const isHttps = process.env.APP_URL?.startsWith('https://');
    const isHmrDisabled = process.env.DISABLE_HMR === 'true';

    console.log(`[Myanmar Recap Studio] Mounting Vite dev server (HMR: ${isHmrDisabled ? 'disabled' : 'enabled'}, HTTPS: ${isHttps})`);

    const wsConfig = {
      server: httpServer,
      ...(isHttps ? { clientPort: 443, protocol: 'wss' as const } : {}),
    };

    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        host: '0.0.0.0',
        port: PORT,
        ws: wsConfig,
        hmr: wsConfig,
        watch: isHmrDisabled ? null : {},
      },
      appType: 'spa',
    });

    app.use(vite.middlewares);
  } else {
    // Serve static frontend in production
    app.use(express.static('dist'));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve('dist/index.html'));
    });
  }

  // Graceful error handling for duplicate listeners or port in use
  httpServer.on('error', (err: any) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`[Myanmar Recap Studio] Fatal Error: Port ${PORT} is already in use. Waiting before retrying...`);
    } else {
      console.error('[Myanmar Recap Studio] Server error:', err);
    }
  });

  const serverInstance = httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`[Myanmar Recap Studio] Server successfully listening on port ${PORT} (0.0.0.0)`);
  });

  // Graceful shutdown handlers
  const handleShutdown = (signal: string) => {
    console.log(`[Myanmar Recap Studio] Received ${signal}. Closing HTTP server...`);
    serverInstance.close(() => {
      console.log('[Myanmar Recap Studio] HTTP server closed gracefully.');
      process.exit(0);
    });
  };

  process.once('SIGTERM', () => handleShutdown('SIGTERM'));
  process.once('SIGINT', () => handleShutdown('SIGINT'));
}

startServer().catch((err) => {
  console.error('[Myanmar Recap Studio] Failed to start server:', err);
  process.exit(1);
});
