/**
 * Robust API Client with Exponential Backoff, Jitter,
 * Retry-After support, Rate-Limiting (HTTP 429), Idempotency guards,
 * and Dual-Backend Switching (Cloud vs Local Windows).
 */

export interface RequestOptions extends RequestInit {
  maxRetries?: number;
  initialDelayMs?: number;
  maxDelayMs?: number;
  timeoutMs?: number;
  isIdempotent?: boolean;
}

const LOCAL_STORAGE_KEY_BACKEND = 'myanmar_recap_backend_mode';
const LOCAL_STORAGE_KEY_CUSTOM_URL = 'myanmar_recap_custom_url';

export function getActiveBackendConfig(): { mode: 'cloud' | 'local'; baseUrl: string } {
  try {
    const mode = (localStorage.getItem(LOCAL_STORAGE_KEY_BACKEND) as 'cloud' | 'local') || 'cloud';
    const customUrl = localStorage.getItem(LOCAL_STORAGE_KEY_CUSTOM_URL) || 'http://127.0.0.1:7860';
    return {
      mode,
      baseUrl: mode === 'local' ? customUrl.replace(/\/+$/, '') : '',
    };
  } catch {
    return { mode: 'cloud', baseUrl: '' };
  }
}

export function setActiveBackendConfig(mode: 'cloud' | 'local', customUrl?: string) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY_BACKEND, mode);
    if (customUrl) {
      localStorage.setItem(LOCAL_STORAGE_KEY_CUSTOM_URL, customUrl.replace(/\/+$/, ''));
    }
  } catch (e) {
    console.error('Failed to save backend configuration', e);
  }
}

export interface AppError {
  messageEn: string;
  messageMy: string;
  status?: number;
  isRetryable: boolean;
  code?: string;
}

export function translateError(error: any): AppError {
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    return {
      messageEn: 'You are currently offline. Please check your internet connection.',
      messageMy: 'အင်တာနက်လိုင်း ပြတ်တောက်နေပါသည်။ သင်၏အင်တာနက်ချိတ်ဆက်မှုကို စစ်ဆေးပါ။',
      isRetryable: true,
      code: 'OFFLINE',
    };
  }

  const message = error?.message || String(error);

  if (error?.name === 'AbortError' || message.includes('aborted') || message.includes('timeout')) {
    return {
      messageEn: 'The request timed out or was cancelled. Please try again.',
      messageMy: 'တောင်းဆိုမှု အချိန်ပြည့်သွားပါသည် သို့မဟုတ် ပယ်ဖျက်လိုက်ပါသည်။ ပြန်လည်ကြိုးစားပါ။',
      isRetryable: true,
      code: 'TIMEOUT',
    };
  }

  if (message.includes('Failed to fetch') || message.includes('NetworkError') || message.includes('ECONNREFUSED')) {
    const { mode, baseUrl } = getActiveBackendConfig();
    if (mode === 'local') {
      return {
        messageEn: `Cannot connect to Local Windows Backend at ${baseUrl}. Please make sure 'start.bat' is running.`,
        messageMy: `Local Windows Backend (${baseUrl}) သို့ ချိတ်ဆက်၍ မရပါ။ 'start.bat' ဖိုင်ကို ဖွင့်ထားခြင်းရှိမရှိ စစ်ဆေးပါ။`,
        isRetryable: true,
        code: 'CONNECTION_REFUSED',
      };
    }
    return {
      messageEn: 'Cannot connect to backend server. Server may be temporarily starting up or rebooting.',
      messageMy: 'Backend ဆာဗာသို့ ချိတ်ဆက်၍ မရနိုင်ပါ။ ဆာဗာ စတင်လည်ပတ်နေခြင်းရှိမရှိ စစ်ဆေးပါ။',
      isRetryable: true,
      code: 'SERVER_UNREACHABLE',
    };
  }

  if (error?.status === 429) {
    return {
      messageEn: 'Rate limit reached (HTTP 429). The system is temporarily busy; please wait a moment.',
      messageMy: 'လုပ်ဆောင်ချက်များ များပြားလွန်းနေပါသည် (HTTP 429)။ ခေတ္တစောင့်ဆိုင်းပြီး ပြန်လည်ကြိုးစားပါ။',
      status: 429,
      isRetryable: true,
      code: 'RATE_LIMIT',
    };
  }

  if (error?.status === 503) {
    return {
      messageEn: 'The server is temporarily overloaded or undergoing maintenance (HTTP 503).',
      messageMy: 'ဆာဗာတွင် လုပ်ငန်းများ ပြည့်နှက်နေပါသည် သို့မဟုတ် ပြင်ဆင်နေပါသည် (HTTP 503)။ ခေတ္တစောင့်ပြီး ပြန်လည်ကြိုးစားပါ။',
      status: 503,
      isRetryable: true,
      code: 'SERVICE_UNAVAILABLE',
    };
  }

  if (error?.status === 502) {
    return {
      messageEn: 'Bad Gateway (HTTP 502). The upstream backend is temporarily unresponsive.',
      messageMy: 'ဆာဗာ ချိတ်ဆက်မှု ယာယီ ချွတ်ယွင်းနေပါသည် (HTTP 502)။ ခေတ္တအကြာတွင် ပြန်လည်ကြိုးစားပါ။',
      status: 502,
      isRetryable: true,
      code: 'BAD_GATEWAY',
    };
  }

  if (error?.status === 504) {
    return {
      messageEn: 'Gateway Timeout (HTTP 504). Video or audio processing took longer than expected.',
      messageMy: 'လုပ်ဆောင်ချိန် ကြာမြင့်လွန်းသောကြောင့် အချိန်ပြည့်သွားပါသည် (HTTP 504)။ ဗီဒီယိုဖိုင် အရွယ်အစား သို့မဟုတ် လုပ်ငန်းစဉ်ကို ပြန်လည်ကြိုးစားပါ။',
      status: 504,
      isRetryable: true,
      code: 'GATEWAY_TIMEOUT',
    };
  }

  if (error?.status === 500) {
    return {
      messageEn: message || 'Internal Server Error (HTTP 500).',
      messageMy: 'ဆာဗာတွင်း လုပ်ဆောင်ချက် ချို့ယွင်းချက် ဖြစ်ပွားခဲ့သည် (HTTP 500)။',
      status: 500,
      isRetryable: true,
      code: 'INTERNAL_ERROR',
    };
  }

  if (error?.status === 413) {
    return {
      messageEn: 'File is too large to process. Please upload a smaller video or extract audio first.',
      messageMy: 'ဖိုင်အရွယ်အစား ကြီးလွန်းပါသည်။ ဗီဒီယိုဖိုင် ပိုမိုသေးငယ်သောဖိုင်ကို တင်ပေးပါ။',
      status: 413,
      isRetryable: false,
      code: 'PAYLOAD_TOO_LARGE',
    };
  }

  if (error?.status === 415 || message.includes('unsupported codec') || message.includes('codec')) {
    return {
      messageEn: 'Unsupported video or audio format. Please use standard MP4, MOV, MKV, or WebM.',
      messageMy: 'ဤဗီဒီယို Codec ပုံစံကို လက်မခံပါ။ စံ MP4, MOV, MKV သို့မဟုတ် WebM ဖိုင်များကို အသုံးပြုပါ။',
      status: error?.status || 415,
      isRetryable: false,
      code: 'UNSUPPORTED_MEDIA',
    };
  }

  return {
    messageEn: message || 'An unexpected error occurred.',
    messageMy: 'မမျှော်လင့်ထားသော ချွတ်ယွင်းချက်တစ်ခု ဖြစ်ပွားခဲ့ပါသည်။',
    status: error?.status,
    isRetryable: error?.status ? [429, 500, 502, 503, 504].includes(error.status) : false,
    code: 'UNKNOWN',
  };
}

/**
 * Fetch wrapper with bounded exponential backoff and jitter.
 * Safely retries transient HTTP 429/5xx and network errors for idempotent requests.
 */
export async function apiFetch<T = any>(endpoint: string, options: RequestOptions = {}): Promise<T> {
  const {
    maxRetries = 3,
    initialDelayMs = 800,
    maxDelayMs = 5000,
    timeoutMs = 60000,
    isIdempotent,
    ...fetchOptions
  } = options;

  const method = (fetchOptions.method || 'GET').toUpperCase();
  // Safe idempotent methods can be retried automatically; non-idempotent requires explicit flag
  const canAutoRetry = isIdempotent !== undefined ? isIdempotent : ['GET', 'HEAD', 'OPTIONS'].includes(method);

  const { baseUrl } = getActiveBackendConfig();
  const url = endpoint.startsWith('http') ? endpoint : `${baseUrl}${endpoint}`;

  let attempt = 0;
  let delay = initialDelayMs;

  while (true) {
    attempt++;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

    // Merge external signal if passed
    if (fetchOptions.signal) {
      fetchOptions.signal.addEventListener('abort', () => controller.abort());
    }

    try {
      const response = await fetch(url, {
        ...fetchOptions,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        // Safe recoverable status codes: 429, 500, 502, 503, 504
        const isRecoverable = [429, 500, 502, 503, 504].includes(response.status);

        if (isRecoverable && canAutoRetry && attempt <= maxRetries) {
          // Check Retry-After header
          const retryAfter = response.headers.get('Retry-After');
          let waitTime = delay;
          if (retryAfter) {
            const parsed = parseInt(retryAfter, 10);
            if (!isNaN(parsed) && parsed > 0) {
              waitTime = Math.min(maxDelayMs, parsed * 1000);
            }
          } else {
            // Exponential backoff with jitter
            const jitter = Math.random() * 300;
            waitTime = Math.min(maxDelayMs, delay + jitter);
            delay *= 2;
          }

          console.warn(`[apiFetch] HTTP ${response.status} on attempt ${attempt}. Retrying in ${Math.round(waitTime)}ms...`);
          await new Promise((resolve) => setTimeout(resolve, waitTime));
          continue;
        }

        // Try to parse JSON error response safely
        let errData: any = null;
        try {
          errData = await response.json();
        } catch {
          errData = { error: response.statusText };
        }

        const customError: any = new Error(errData?.error || errData?.detail || `HTTP Error ${response.status}`);
        customError.status = response.status;
        customError.data = errData;
        throw customError;
      }

      // Check content type to parse json vs blob
      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        return (await response.json()) as T;
      } else if (contentType.includes('text/')) {
        return (await response.text()) as unknown as T;
      } else {
        return (await response.blob()) as unknown as T;
      }
    } catch (err: any) {
      clearTimeout(timeoutId);

      const isNetworkOrTransient =
        !err?.status || [429, 500, 502, 503, 504].includes(err.status) || err.name === 'AbortError';

      if (canAutoRetry && attempt <= maxRetries && isNetworkOrTransient && err.name !== 'AbortError') {
        const jitter = Math.random() * 300;
        const waitTime = Math.min(maxDelayMs, delay + jitter);
        delay *= 2;
        console.warn(`[apiFetch] Transient error on attempt ${attempt}: ${err.message}. Retrying in ${Math.round(waitTime)}ms...`);
        await new Promise((resolve) => setTimeout(resolve, waitTime));
        continue;
      }
      throw err;
    }
  }
}
