import React, { useState } from 'react';
import { X, Check, Server, Monitor, AlertCircle, ExternalLink, Download, FileCode, CheckCircle2 } from 'lucide-react';
import { getActiveBackendConfig, setActiveBackendConfig } from '../utils/apiClient';
import { SystemHealth } from '../types/recap';

interface BackendModalProps {
  isOpen: boolean;
  onClose: () => void;
  health: SystemHealth | null;
  onRefreshHealth: () => void;
}

export const BackendModal: React.FC<BackendModalProps> = ({
  isOpen,
  onClose,
  health,
  onRefreshHealth,
}) => {
  const currentConfig = getActiveBackendConfig();
  const [selectedMode, setSelectedMode] = useState<'cloud' | 'local'>(currentConfig.mode);
  const [localUrl, setLocalUrl] = useState(currentConfig.baseUrl || 'http://127.0.0.1:7860');
  const [testResult, setTestResult] = useState<string | null>(null);
  const [testing, setTesting] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    setActiveBackendConfig(selectedMode, localUrl);
    onRefreshHealth();
    onClose();
  };

  const handleTestConnection = async () => {
    setTesting(true);
    setTestResult(null);
    const targetUrl = selectedMode === 'local' ? `${localUrl.replace(/\/+$/, '')}/api/health` : '/api/health';

    try {
      const res = await fetch(targetUrl, { signal: AbortSignal.timeout(4000) });
      if (res.ok) {
        const data = await res.json();
        setTestResult(`✓ ချိတ်ဆက်မှု အောင်မြင်ပါသည် (Connected). FFmpeg: ${data.ffmpegAvailable ? 'Yes' : 'No'}, TTS: ${data.ttsAvailable ? 'Yes' : 'No'}`);
      } else {
        setTestResult(`✕ တုံ့ပြန်မှု ချို့ယွင်းနေပါသည်: HTTP ${res.status}`);
      }
    } catch (e: any) {
      setTestResult(`✕ ချိတ်ဆက်၍ မရပါ: ${e.message || 'Connection refused'}. 'start.bat' ဖွင့်ထားခြင်း ရှိမရှိ စစ်ဆေးပါ။`);
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl max-w-xl w-full p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-neutral-400 hover:text-white p-1 rounded-md hover:bg-neutral-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-lg font-semibold text-white mb-1">
          Backend Configuration (ဆာဗာ ချိတ်ဆက်မှု စနစ်)
        </h3>
        <p className="text-xs text-neutral-400 mb-6">
          Myanmar Recap Studio supports dual execution: Online Cloud Studio or Local Windows 10/11 workstation mode.
        </p>

        {/* Mode Selector */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <button
            type="button"
            onClick={() => setSelectedMode('cloud')}
            className={`p-4 rounded-lg border text-left transition-all ${
              selectedMode === 'cloud'
                ? 'border-amber-500/60 bg-amber-500/10 text-white'
                : 'border-neutral-800 bg-neutral-950/50 text-neutral-400 hover:border-neutral-700'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <Server className={`w-5 h-5 ${selectedMode === 'cloud' ? 'text-amber-400' : 'text-neutral-500'}`} />
              {selectedMode === 'cloud' && <Check className="w-4 h-4 text-amber-400" />}
            </div>
            <div className="font-medium text-sm text-neutral-200">Cloud Studio Server</div>
            <div className="text-xs text-neutral-400 mt-1">
              အွန်လိုင်းမှ တိုက်ရိုက် အသုံးပြုခြင်း (Express + Gemini + Edge TTS)
            </div>
          </button>

          <button
            type="button"
            onClick={() => setSelectedMode('local')}
            className={`p-4 rounded-lg border text-left transition-all ${
              selectedMode === 'local'
                ? 'border-blue-500/60 bg-blue-500/10 text-white'
                : 'border-neutral-800 bg-neutral-950/50 text-neutral-400 hover:border-neutral-700'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <Monitor className={`w-5 h-5 ${selectedMode === 'local' ? 'text-blue-400' : 'text-neutral-500'}`} />
              {selectedMode === 'local' && <Check className="w-4 h-4 text-blue-400" />}
            </div>
            <div className="font-medium text-sm text-neutral-200">Local Windows Backend</div>
            <div className="text-xs text-neutral-400 mt-1">
              Windows 10/11 တွင် faster-whisper ဖြင့် ဒေသတွင်း run ခြင်း
            </div>
          </button>
        </div>

        {/* Local URL Input if Local Mode selected */}
        {selectedMode === 'local' && (
          <div className="mb-6 space-y-2 bg-neutral-950 p-4 rounded-lg border border-neutral-800">
            <label className="block text-xs font-medium text-neutral-300">
              Local Backend URL (FastAPI / Uvicorn Port)
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={localUrl}
                onChange={(e) => setLocalUrl(e.target.value)}
                placeholder="http://127.0.0.1:7860"
                className="flex-1 bg-neutral-900 border border-neutral-700 rounded-md px-3 py-2 text-xs font-mono text-neutral-100 focus:outline-none focus:border-blue-500"
              />
              <button
                type="button"
                onClick={handleTestConnection}
                disabled={testing}
                className="px-3 py-2 text-xs font-medium rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 transition-colors whitespace-nowrap"
              >
                {testing ? 'စစ်ဆေးနေသည်...' : 'Test Ping'}
              </button>
            </div>
            {testResult && (
              <p className={`text-xs mt-2 ${testResult.startsWith('✓') ? 'text-emerald-400' : 'text-amber-400'}`}>
                {testResult}
              </p>
            )}
            <div className="mt-3 text-xs text-neutral-400">
              💡 Windows ကွန်ပျူတာပေါ်တွင် <code className="text-blue-300">backend/start.bat</code> ကို ဖွင့်ထားရန် လိုအပ်ပါသည်။
            </div>
          </div>
        )}

        {/* Current Health Status Summary */}
        <div className="border-t border-neutral-800 pt-4 mb-6">
          <div className="text-xs font-medium text-neutral-400 mb-2">Backend Capabilities Status:</div>
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="p-2 rounded bg-neutral-950 border border-neutral-800 flex items-center gap-2">
              <CheckCircle2 className={`w-3.5 h-3.5 ${health?.ffmpegAvailable ? 'text-emerald-400' : 'text-neutral-600'}`} />
              <span className="text-neutral-300">FFmpeg Audio</span>
            </div>
            <div className="p-2 rounded bg-neutral-950 border border-neutral-800 flex items-center gap-2">
              <CheckCircle2 className={`w-3.5 h-3.5 ${health?.ttsAvailable ? 'text-emerald-400' : 'text-neutral-600'}`} />
              <span className="text-neutral-300">Edge TTS</span>
            </div>
            <div className="p-2 rounded bg-neutral-950 border border-neutral-800 flex items-center gap-2">
              <CheckCircle2 className={`w-3.5 h-3.5 ${health?.aiAvailable ? 'text-emerald-400' : 'text-neutral-600'}`} />
              <span className="text-neutral-300">Gemini/Whisper</span>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-end gap-3 border-t border-neutral-800 pt-4">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-neutral-400 hover:text-white transition-colors"
          >
            မလုပ်တော့ပါ (Cancel)
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-4 py-2 text-xs font-medium bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-lg transition-colors font-semibold"
          >
            သိမ်းဆည်းမည် (Apply Settings)
          </button>
        </div>
      </div>
    </div>
  );
};
