import React from 'react';
import { AlertTriangle, RefreshCw, XCircle, WifiOff } from 'lucide-react';
import { AppError } from '../utils/apiClient';

interface ErrorAlertProps {
  error: AppError | string | null;
  onRetry?: () => void;
  onDismiss?: () => void;
  retrying?: boolean;
}

export const ErrorAlert: React.FC<ErrorAlertProps> = ({
  error,
  onRetry,
  onDismiss,
  retrying = false,
}) => {
  if (!error) return null;

  const isAppError = typeof error === 'object' && 'messageEn' in error;
  const messageEn = isAppError ? error.messageEn : String(error);
  const messageMy = isAppError ? error.messageMy : 'ချွတ်ယွင်းချက်တစ်ခု ဖြစ်ပွားခဲ့ပါသည်။';
  const isRetryable = isAppError ? error.isRetryable : true;
  const isOffline = isAppError && error.code === 'OFFLINE';

  return (
    <div className="rounded-lg border border-red-500/40 bg-red-950/30 p-4 mb-6 text-neutral-200 animate-in fade-in duration-200">
      <div className="flex items-start gap-3">
        <div className="p-1 rounded bg-red-500/20 text-red-400 shrink-0 mt-0.5">
          {isOffline ? <WifiOff className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
        </div>

        <div className="flex-1 min-w-0">
          <div className="font-semibold text-sm text-red-200 mb-0.5 leading-snug">
            {messageMy}
          </div>
          <div className="text-xs text-red-300/80 leading-relaxed font-mono">
            {messageEn}
          </div>

          {onRetry && isRetryable && (
            <div className="mt-3 flex items-center gap-3">
              <button
                type="button"
                onClick={onRetry}
                disabled={retrying}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md bg-red-500/20 hover:bg-red-500/30 text-red-200 border border-red-500/30 transition-colors"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${retrying ? 'animate-spin' : ''}`} />
                <span>{retrying ? 'ပြန်လည်ကြိုးစားနေသည်...' : 'ပြန်လည်ကြိုးစားပါ (Retry Step)'}</span>
              </button>
            </div>
          )}
        </div>

        {onDismiss && (
          <button
            onClick={onDismiss}
            className="text-neutral-500 hover:text-neutral-300 p-1 rounded transition-colors"
          >
            <XCircle className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
