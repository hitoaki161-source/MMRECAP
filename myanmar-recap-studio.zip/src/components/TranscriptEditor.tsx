import React, { useState, useEffect } from 'react';
import { FileText, RefreshCw, Copy, Check, Download, ArrowRight, Languages, Sparkles } from 'lucide-react';
import { VideoMetadata, TranscriptionResult } from '../types/recap';
import { apiFetch, translateError, AppError } from '../utils/apiClient';
import { ErrorAlert } from './ErrorAlert';

interface TranscriptEditorProps {
  video: VideoMetadata | null;
  transcription: TranscriptionResult | null;
  onTranscriptionComplete: (result: TranscriptionResult) => void;
  onProceedToTranslate: () => void;
  autoStart?: boolean;
  onAutoStartHandled?: () => void;
}

export const TranscriptEditor: React.FC<TranscriptEditorProps> = ({
  video,
  transcription,
  onTranscriptionComplete,
  onProceedToTranslate,
  autoStart,
  onAutoStartHandled,
}) => {
  const [sourceLanguage, setSourceLanguage] = useState<string>('auto');
  const [processing, setProcessing] = useState(false);
  const [jobProgress, setJobProgress] = useState(0);
  const [statusMessageBurmese, setStatusMessageBurmese] = useState('');
  const [statusMessageEnglish, setStatusMessageEnglish] = useState('');
  const [currentTaskId, setCurrentTaskId] = useState<string | null>(null);
  const [error, setError] = useState<AppError | null>(null);
  const [editableText, setEditableText] = useState(transcription?.fullText || '');
  const [viewMode, setViewMode] = useState<'paragraphs' | 'timestamps' | 'srt'>('paragraphs');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (transcription?.fullText) {
      setEditableText(transcription.fullText);
    }
  }, [transcription]);

  const languages = [
    { code: 'auto', name: 'အလိုအလျောက် စစ်ဆေးမည် (Auto Detect)' },
    { code: 'en', name: 'English (အင်္ဂလိပ်)' },
    { code: 'ko', name: 'Korean (ကိုရီးယား)' },
    { code: 'zh', name: 'Chinese (တရုတ်)' },
    { code: 'ja', name: 'Japanese (ဂျပန်)' },
    { code: 'th', name: 'Thai (ထိုင်း)' },
    { code: 'my', name: 'Burmese (မြန်မာ)' },
    { code: 'hi', name: 'Hindi (ဟိန္ဒီ)' },
  ];

  const startTranscription = async () => {
    const activeFilename = video?.filename || (video as any)?.fileName;
    if (!video || !activeFilename || typeof activeFilename !== 'string' || !activeFilename.trim()) {
      setError({
        messageEn: 'No valid uploaded video file found. Please upload a video file first before transcribing.',
        messageMy: 'တင်သွင်းထားသော ဗီဒီယိုဖိုင် အချက်အလက် မရှိသေးပါ။ အဆင့် ၁ တွင် ဗီဒီယိုဖိုင် အရင်တင်ပေးပါ။',
        isRetryable: false,
      });
      return;
    }

    setError(null);
    setProcessing(true);
    setJobProgress(15);
    setStatusMessageBurmese('ဗီဒီယိုမှ အသံဖိုင် စတင်ခွဲထုတ်ရန် ပြင်ဆင်နေပါသည်...');
    setStatusMessageEnglish('Preparing audio extraction via FFmpeg...');

    try {
      const initRes = await apiFetch('/api/transcribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filename: activeFilename.trim(),
          sourceLanguage,
        }),
      });

      const jobId = initRes.jobId;
      setCurrentTaskId(jobId);

      // Poll job progress
      const pollInterval = setInterval(async () => {
        try {
          const jobData = await apiFetch(`/api/jobs/${jobId}`);
          setJobProgress(jobData.progress || 0);
          setStatusMessageBurmese(jobData.statusMessageBurmese || '');
          setStatusMessageEnglish(jobData.statusMessageEnglish || '');

          if (jobData.status === 'completed') {
            clearInterval(pollInterval);
            setProcessing(false);
            if (jobData.result) {
              setEditableText(jobData.result.fullText);
              onTranscriptionComplete(jobData.result);
            }
          } else if (jobData.status === 'failed') {
            clearInterval(pollInterval);
            setProcessing(false);
            setError({
              messageEn: jobData.error || 'Transcription job failed',
              messageMy: jobData.statusMessageBurmese || 'စာသားဖော်ယူမှု မအောင်မြင်ပါ',
              isRetryable: true,
            });
          }
        } catch (pollErr: any) {
          console.warn('Polling error:', pollErr);
        }
      }, 1500);
    } catch (err: any) {
      setProcessing(false);
      setError(translateError(err));
    }
  };

  // Auto-start transcription if triggered from the VideoUploader button
  useEffect(() => {
    const activeFilename = video?.filename || (video as any)?.fileName;
    if (autoStart && video && activeFilename && !transcription && !processing) {
      if (onAutoStartHandled) {
        onAutoStartHandled();
      }
      startTranscription();
    }
  }, [autoStart, video, transcription, processing]);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(editableText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadAsTxt = () => {
    const blob = new Blob([editableText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Transcript_${video?.originalName || 'video'}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadAsSrt = () => {
    const srtData = transcription?.srtContent || editableText;
    const blob = new Blob([srtData], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Subtitles_${video?.originalName || 'video'}.srt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-400" />
            <span>အဆင့် ၂: စကားပြောအသံမှ စာသားဖော်ယူခြင်း (Dialogue Transcript)</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            Extracts audio with FFmpeg and runs Whisper/Gemini speech-to-text with scene paragraph breaks.
          </p>
        </div>

        {/* Source Language Selector */}
        <div className="flex items-center gap-2">
          <label className="text-xs text-neutral-400 whitespace-nowrap">မူရင်းဘာသာစကား:</label>
          <select
            value={sourceLanguage}
            onChange={(e) => setSourceLanguage(e.target.value)}
            disabled={processing}
            className="bg-neutral-900 border border-neutral-700 rounded-md px-3 py-1.5 text-xs text-neutral-200 focus:outline-none focus:border-amber-500"
          >
            {languages.map((l) => (
              <option key={l.code} value={l.code}>
                {l.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      <ErrorAlert error={error} onRetry={startTranscription} onDismiss={() => setError(null)} retrying={processing} />

      {/* Action / Trigger Bar when no transcript has been fetched yet */}
      {!transcription && !processing && (
        <div className="border border-neutral-800 bg-neutral-900/60 rounded-2xl p-8 text-center mb-6 shadow-xl">
          <div className="w-14 h-14 rounded-full bg-amber-500/10 text-amber-400 mx-auto flex items-center justify-center mb-4">
            <Languages className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-neutral-100 mb-1">
            ဗီဒီယိုဖိုင်မှ မူရင်းစကားပြောများကို စာသားအဖြစ် ဖော်ယူရန် အဆင်သင့်ဖြစ်ပါပြီ
          </h3>
          <p className="text-xs text-neutral-400 max-w-lg mx-auto mb-6">
            {video
              ? `ဖိုင်အမည်: ${video.originalName} (${(video.size / (1024 * 1024)).toFixed(1)} MB)`
              : 'ဗီဒီယိုဖိုင် အရင်တင်ပေးပါ'}
          </p>

          <button
            type="button"
            onClick={startTranscription}
            disabled={!video || !video.filename || processing}
            aria-label="Start Transcription and Translation"
            className="px-8 py-3.5 text-xs font-bold rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-[0.98] text-neutral-950 transition-all shadow-lg hover:shadow-amber-500/20 disabled:opacity-50 cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              <span>စကားပြော စာသားဖော်ယူမည် (Start Transcription & Translation)</span>
              <ArrowRight className="w-4 h-4" />
            </span>
          </button>
        </div>
      )}

      {/* Processing Progress Status */}
      {processing && (
        <div className="border border-neutral-800 bg-neutral-900 rounded-2xl p-6 mb-6 shadow-xl">
          <div className="flex items-center justify-between text-xs mb-2">
            <div className="flex items-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
              <span className="font-semibold text-neutral-200">{statusMessageBurmese}</span>
            </div>
            <span className="font-mono text-amber-400 tabular-nums">{jobProgress}%</span>
          </div>

          <div className="w-full bg-neutral-800 rounded-full h-2.5 overflow-hidden mb-3">
            <div
              className="bg-amber-500 h-2.5 rounded-full transition-all duration-300"
              style={{ width: `${jobProgress}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-neutral-500 font-mono">
            <span>{statusMessageEnglish}</span>
            {currentTaskId && <span>Task ID: {currentTaskId}</span>}
          </div>
        </div>
      )}

      {/* Transcript Results & Editor */}
      {(transcription || editableText) && (
        <div className="border border-neutral-800 bg-neutral-900 rounded-2xl p-6 shadow-xl space-y-4">
          {/* Controls toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-neutral-800">
            {/* View Mode Tabs */}
            <div className="flex items-center gap-1 p-1 bg-neutral-950 rounded-lg border border-neutral-800">
              <button
                type="button"
                onClick={() => setViewMode('paragraphs')}
                className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                  viewMode === 'paragraphs'
                    ? 'bg-neutral-800 text-white shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                စာပိုဒ်များ (Paragraphs)
              </button>
              <button
                type="button"
                onClick={() => setViewMode('timestamps')}
                className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                  viewMode === 'timestamps'
                    ? 'bg-neutral-800 text-white shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                အချိန်မှတ်များနှင့် (Timestamps)
              </button>
              <button
                type="button"
                onClick={() => setViewMode('srt')}
                className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                  viewMode === 'srt'
                    ? 'bg-neutral-800 text-white shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                SRT Subtitles
              </button>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={copyToClipboard}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors border border-neutral-700 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'ကူးယူပြီးပါပြီ' : 'Copy'}</span>
              </button>

              <button
                type="button"
                onClick={downloadAsTxt}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors border border-neutral-700 cursor-pointer"
                title="Download as TXT"
              >
                <Download className="w-3.5 h-3.5" />
                <span>TXT</span>
              </button>

              <button
                type="button"
                onClick={downloadAsSrt}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors border border-neutral-700 cursor-pointer"
                title="Download as SRT"
              >
                <Download className="w-3.5 h-3.5" />
                <span>SRT</span>
              </button>
            </div>
          </div>

          {/* Transcript Content depending on view mode */}
          {viewMode === 'paragraphs' ? (
            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-2">
                မူရင်း စကားပြော စာသား (ပြင်ဆင်နိုင်သည် / Fully Editable):
              </label>
              <textarea
                value={editableText}
                onChange={(e) => {
                  setEditableText(e.target.value);
                  if (transcription) {
                    onTranscriptionComplete({ ...transcription, fullText: e.target.value });
                  }
                }}
                rows={12}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-lg p-4 text-sm text-neutral-100 font-sans leading-relaxed focus:outline-none focus:border-amber-500 resize-y"
                placeholder="Transcribed dialogue will appear here..."
              />
            </div>
          ) : viewMode === 'timestamps' ? (
            <div className="max-h-96 overflow-y-auto space-y-2 pr-1">
              {transcription?.segments && transcription.segments.length > 0 ? (
                transcription.segments.map((seg) => (
                  <div key={seg.id} className="p-2.5 rounded bg-neutral-950 border border-neutral-800 text-xs flex gap-3">
                    <span className="font-mono text-amber-400 shrink-0 font-medium tabular-nums">
                      {seg.start} → {seg.end}
                    </span>
                    <span className="text-neutral-300">{seg.text}</span>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center text-xs text-neutral-500">No timestamped segments available</div>
              )}
            </div>
          ) : (
            <div className="bg-neutral-950 rounded-lg p-3 border border-neutral-800 max-h-96 overflow-y-auto font-mono text-xs text-neutral-300 whitespace-pre-wrap">
              {transcription?.srtContent || 'No SRT generated'}
            </div>
          )}

          {/* Footer Next Button */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-neutral-800">
            <span className="text-xs text-neutral-500">
              စကားလုံးအရေအတွက်: <span className="font-mono text-neutral-300">{editableText.split(/\s+/).filter(Boolean).length}</span> words
            </span>

            <button
              type="button"
              onClick={onProceedToTranslate}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 text-xs font-bold rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 transition-all shadow-md active:scale-[0.98] cursor-pointer"
            >
              <span>အဆင့် ၃ သို့ ဆက်သွားမည် (Next: Myanmar Recap)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
