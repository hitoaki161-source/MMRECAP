import React from 'react';
import { Upload, FileText, Languages, Volume2, Download, Check } from 'lucide-react';
import { RecapStep } from '../types/recap';

interface StepNavigationProps {
  currentStep: RecapStep;
  onSelectStep: (step: RecapStep) => void;
  completedSteps: {
    upload: boolean;
    transcribe: boolean;
    translate: boolean;
    voice: boolean;
    export: boolean;
  };
}

export const StepNavigation: React.FC<StepNavigationProps> = ({
  currentStep,
  onSelectStep,
  completedSteps,
}) => {
  const steps: { id: RecapStep; labelEn: string; labelMy: string; icon: any }[] = [
    { id: 'upload', labelEn: '1. Upload Video', labelMy: 'ဗီဒီယိုတင်ခြင်း', icon: Upload },
    { id: 'transcribe', labelEn: '2. Transcript', labelMy: 'စာသားဖော်ယူခြင်း', icon: FileText },
    { id: 'translate', labelEn: '3. Myanmar Recap', labelMy: 'မြန်မာ Recap ဇာတ်ညွှန်း', icon: Languages },
    { id: 'voice', labelEn: '4. Voice Narration', labelMy: 'မြန်မာအသံဖိုင်ဖန်တီးခြင်း', icon: Volume2 },
    { id: 'export', labelEn: '5. Export & Save', labelMy: 'ဒေါင်းလုဒ်ရယူခြင်း', icon: Download },
  ];

  return (
    <nav className="border-b border-neutral-800 bg-neutral-900/40">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between overflow-x-auto py-2.5 gap-2 no-scrollbar">
          {steps.map((step) => {
            const Icon = step.icon;
            const isActive = currentStep === step.id;
            const isCompleted = completedSteps[step.id];

            return (
              <button
                key={step.id}
                onClick={() => onSelectStep(step.id)}
                className={`flex items-center gap-3 px-4 py-2 rounded-lg text-left transition-all whitespace-nowrap shrink-0 group ${
                  isActive
                    ? 'bg-neutral-800 border border-neutral-700 text-white shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
                }`}
              >
                <div
                  className={`w-7 h-7 rounded-md flex items-center justify-center text-xs transition-colors ${
                    isActive
                      ? 'bg-amber-500 text-neutral-950 font-bold'
                      : isCompleted
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-neutral-800 text-neutral-400 group-hover:text-neutral-200'
                  }`}
                >
                  {isCompleted && !isActive ? <Check className="w-4 h-4" /> : <Icon className="w-3.5 h-3.5" />}
                </div>

                <div>
                  <div className={`text-xs font-semibold leading-tight ${isActive ? 'text-white' : 'text-neutral-300'}`}>
                    {step.labelEn}
                  </div>
                  <div className="text-[11px] text-neutral-500 leading-tight">
                    {step.labelMy}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
