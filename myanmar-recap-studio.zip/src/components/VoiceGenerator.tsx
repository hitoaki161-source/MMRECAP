import React, { useState, useRef, useEffect } from 'react';
import { Volume2, Play, Pause, Download, RefreshCw, Sliders, CheckCircle2, Music, ArrowRight, RotateCcw } from 'lucide-react';
import { VoiceOption, TTSResult } from '../types/recap';
import { apiFetch, translateError, AppError, getActiveBackendConfig } from '../utils/apiClient';
import { ErrorAlert } from './ErrorAlert';

interface VoiceGeneratorProps {
  burmeseText: string;
  ttsResult: TTSResult | null;
  onTTSComplete: (result: TTSResult) => void;
  onProceedToExport: () => void;
}

export const VoiceGenerator: React.FC<VoiceGeneratorProps> = ({
  burmeseText,
  ttsResult,
  onTTSComplete,
  onProceedToExport,
}) => {
  const [selectedVoice, setSelectedVoice] = useState<'my-MM-NilarNeural' | 'my-MM-ThihaNeural'>('my-MM-NilarNeural');
  const [speechRate, setSpeechRate] = useState<number>(0); // -20 to +30 %
  const [speechPitch, setSpeechPitch] = useState<number>(0); // -10 to +10 Hz
  const [synthesizing, setSynthesizing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusMessageBurmese, setStatusMessageBurmese] = useState('');
  const [statusMessageEnglish, setStatusMessageEnglish] = useState('');
  const [error, setError] = useState<AppError | null>(null);

  // Audio Player State
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const voices: VoiceOption[] = [
    {
      id: 'my-MM-NilarNeural',
      name: 'နီလာ (Nilar)',
      gender: 'female',
      description: 'အမျိုးသမီး အသံ - ဇာတ်ကြောင်းပြောရန် ကြည်လင်ပြတ်သားပြီး သဘာဝကျသည် (Clear & Expressive)',
    },
    {
      id: 'my-MM-ThihaNeural',
      name: 'သီဟ (Thiha)',
      gender: 'male',
      description: 'အမျိုးသား အသံ - ရုပ်ရှင် Recap အတွက် လေးနက်ခိုင်မာပြီး ဆွဲဆောင်မှုရှိသည် (Deep & Resonant)',
    },
  ];

  const startVoiceGeneration = async () => {
    if (!burmeseText.trim()) {
      setError({
        messageEn: 'Myanmar text is empty. Please enter or translate text first.',
        messageMy: 'မြန်မာစာသား မရှိသေးပါ။ အဆင့် ၃ တွင် စာသားအရင် ဘာသာပြန်ပါ သို့မဟုတ် ရိုက်ထည့်ပါ။',
        isRetryable: false,
      });
      return;
    }

    setError(null);
    setSynthesizing(true);
    setProgress(15);
    setStatusMessageBurmese('Microsoft Edge TTS အင်ဂျင်သို့ စတင်ချိတ်ဆက်နေပါသည်...');
    setStatusMessageEnglish('Connecting to Microsoft Edge TTS...');

    const rateParam = speechRate >= 0 ? `+${speechRate}%` : `${speechRate}%`;
    const pitchParam = speechPitch >= 0 ? `+${speechPitch}Hz` : `${speechPitch}Hz`;

    try {
      const initRes = await apiFetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: burmeseText,
          voiceId: selectedVoice,
          rate: rateParam,
          pitch: pitchParam,
        }),
      });

      const jobId = initRes.jobId;

      // Poll TTS job status
      const pollInterval = setInterval(async () => {
        try {
          const jobData = await apiFetch(`/api/jobs/${jobId}`);
          setProgress(jobData.progress || 0);
          setStatusMessageBurmese(jobData.statusMessageBurmese || '');
          setStatusMessageEnglish(jobData.statusMessageEnglish || '');

          if (jobData.status === 'completed') {
            clearInterval(pollInterval);
            setSynthesizing(false);
            if (jobData.result) {
              const { baseUrl } = getActiveBackendConfig();
              const fullResult: TTSResult = {
                ...jobData.result,
                mp3Url: `${baseUrl}${jobData.result.mp3Url}`,
                wavUrl: `${baseUrl}${jobData.result.wavUrl}`,
              };
              onTTSComplete(fullResult);
            }
          } else if (jobData.status === 'failed') {
            clearInterval(pollInterval);
            setSynthesizing(false);
            setError({
              messageEn: jobData.error || 'TTS voice generation failed',
              messageMy: jobData.statusMessageBurmese || 'အသံသွင်းခြင်း မအောင်မြင်ပါ',
              isRetryable: true,
            });
          }
        } catch (pollErr: any) {
          console.warn('TTS Poll error:', pollErr);
        }
      }, 1500);
    } catch (err: any) {
      setSynthesizing(false);
      setError(translateError(err));
    }
  };

  // Audio playback controls
  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch((e) => console.error('Play error', e));
    }
    setIsPlaying(!isPlaying);
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      setDuration(audioRef.current.duration || 0);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
    }
  };

  const formatSeconds = (sec: number): string => {
    if (isNaN(sec)) return '00:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <Volume2 className="w-5 h-5 text-amber-400" />
          <span>အဆင့် ၄: မြန်မာအသံဖိုင် ဖန်တီးခြင်း (Myanmar Edge TTS Voice Generation)</span>
        </h2>
        <p className="text-xs text-neutral-400 mt-1">
          Authentic Microsoft Edge TTS Myanmar voices (my-MM-NilarNeural & my-MM-ThihaNeural) with chunk stitching and WAV master output.
        </p>
      </div>

      <ErrorAlert error={error} onRetry={startVoiceGeneration} onDismiss={() => setError(null)} retrying={synthesizing} />

      {/* Voice Selection Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {voices.map((v) => {
          const isSelected = selectedVoice === v.id;
          return (
            <button
              key={v.id}
              type="button"
              onClick={() => setSelectedVoice(v.id)}
              disabled={synthesizing}
              className={`p-4 rounded-xl border text-left transition-all ${
                isSelected
                  ? 'border-amber-500/80 bg-amber-500/10 shadow-sm'
                  : 'border-neutral-800 bg-neutral-900/60 hover:border-neutral-700'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold text-neutral-100 flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${isSelected ? 'bg-amber-400' : 'bg-neutral-600'}`} />
                  {v.name}
                </span>
                <span className="text-xs font-mono text-neutral-400">{v.gender === 'female' ? 'အမျိုးသမီး' : 'အမျိုးသား'}</span>
              </div>
              <p className="text-xs text-neutral-400 leading-relaxed">{v.description}</p>
              <div className="mt-3 text-[11px] font-mono text-neutral-500">
                Voice ID: {v.id}
              </div>
            </button>
          );
        })}
      </div>

      {/* Speed & Pitch Controls */}
      <div className="border border-neutral-800 bg-neutral-900 rounded-xl p-5 mb-6">
        <div className="flex items-center gap-2 mb-4">
          <Sliders className="w-4 h-4 text-amber-400" />
          <h3 className="text-xs font-semibold text-neutral-200">
            အသံအမြန်နှုန်းနှင့် အမြင့်အနိမ့် ညှိယူခြင်း (Voice Rate & Pitch)
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
          <div>
            <div className="flex justify-between text-neutral-300 mb-1.5">
              <span>အမြန်နှုန်း (Speed Rate):</span>
              <span className="font-mono text-amber-400 tabular-nums">{speechRate >= 0 ? `+${speechRate}%` : `${speechRate}%`}</span>
            </div>
            <input
              type="range"
              min="-20"
              max="30"
              step="5"
              value={speechRate}
              onChange={(e) => setSpeechRate(parseInt(e.target.value, 10))}
              disabled={synthesizing}
              className="w-full accent-amber-500"
            />
            <div className="flex justify-between text-[10px] text-neutral-500 mt-1">
              <span>-20% (အေးဆေး)</span>
              <span>0% (ပုံမှန်)</span>
              <span>+30% (သွက်သွက်)</span>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-neutral-300 mb-1.5">
              <span>အသံသြဇာ အမြင့်အနိမ့် (Pitch):</span>
              <span className="font-mono text-amber-400 tabular-nums">{speechPitch >= 0 ? `+${speechPitch}Hz` : `${speechPitch}Hz`}</span>
            </div>
            <input
              type="range"
              min="-10"
              max="10"
              step="2"
              value={speechPitch}
              onChange={(e) => setSpeechPitch(parseInt(e.target.value, 10))}
              disabled={synthesizing}
              className="w-full accent-amber-500"
            />
            <div className="flex justify-between text-[10px] text-neutral-500 mt-1">
              <span>-10Hz (သြဇာနက်)</span>
              <span>0Hz (စံသတ်မှတ်ချက်)</span>
              <span>+10Hz (စူးကြည်)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Synthesize Action Button */}
      <div className="text-center mb-6">
        <button
          type="button"
          onClick={startVoiceGeneration}
          disabled={synthesizing || !burmeseText.trim()}
          className="inline-flex items-center gap-2 px-8 py-3 text-sm font-semibold rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 transition-colors shadow-lg shadow-amber-500/10 disabled:opacity-40"
        >
          {synthesizing ? (
            <RefreshCw className="w-4 h-4 animate-spin" />
          ) : (
            <Volume2 className="w-4 h-4" />
          )}
          <span>{synthesizing ? 'အသံဖိုင် ဖန်တီးနေပါသည် (Synthesizing)...' : 'မြန်မာ အသံဇာတ်ကြောင်းပြော ဖိုင်ဖန်တီးပါ (Generate Narration)'}</span>
        </button>
      </div>

      {/* Synthesis Progress Bar */}
      {synthesizing && (
        <div className="border border-neutral-800 bg-neutral-900 rounded-xl p-6 mb-6">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-semibold text-neutral-200 flex items-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
              {statusMessageBurmese}
            </span>
            <span className="font-mono text-amber-400 tabular-nums">{progress}%</span>
          </div>

          <div className="w-full bg-neutral-800 rounded-full h-2 overflow-hidden mb-2">
            <div
              className="bg-amber-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>

          <div className="text-[11px] text-neutral-500 font-mono">
            {statusMessageEnglish}
          </div>
        </div>
      )}

      {/* Audio Player & Download Preview */}
      {ttsResult && (
        <div className="border border-neutral-800 bg-neutral-900 rounded-xl p-6 shadow-xl">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-neutral-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
                <Music className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-neutral-100">
                  မြန်မာ ရုပ်ရှင် Recap အသံဖိုင် (Myanmar Voice Narration)
                </h4>
                <div className="text-xs text-neutral-400 flex items-center gap-2 mt-0.5">
                  <span>Voice: {ttsResult.voiceUsed}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">{formatSeconds(ttsResult.durationSeconds)}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">{(ttsResult.fileSizeBytes / (1024 * 1024)).toFixed(2)} MB</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <a
                href={ttsResult.wavUrl}
                download
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors border border-neutral-700"
              >
                <Download className="w-3.5 h-3.5" />
                <span>WAV (Studio)</span>
              </a>
              <a
                href={ttsResult.mp3Url}
                download
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors border border-neutral-700"
              >
                <Download className="w-3.5 h-3.5" />
                <span>MP3</span>
              </a>
            </div>
          </div>

          {/* Hidden native audio element */}
          <audio
            ref={audioRef}
            src={ttsResult.mp3Url}
            onTimeUpdate={handleTimeUpdate}
            onEnded={() => setIsPlaying(false)}
          />

          {/* Custom Styled Audio Player Controls */}
          <div className="bg-neutral-950 p-4 rounded-lg border border-neutral-800">
            <div className="flex items-center gap-4">
              <button
                type="button"
                onClick={togglePlay}
                className="w-10 h-10 rounded-full bg-amber-500 hover:bg-amber-400 text-neutral-950 flex items-center justify-center transition-colors shrink-0 shadow-sm"
              >
                {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
              </button>

              <div className="flex-1">
                <input
                  type="range"
                  min="0"
                  max={duration || 100}
                  value={currentTime}
                  onChange={handleSeek}
                  className="w-full accent-amber-500"
                />
                <div className="flex justify-between text-[11px] font-mono text-neutral-400 mt-1">
                  <span>{formatSeconds(currentTime)}</span>
                  <span>{formatSeconds(duration || ttsResult.durationSeconds)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Proceed to Export Button */}
          <div className="flex items-center justify-end pt-5 mt-4 border-t border-neutral-800">
            <button
              type="button"
              onClick={onProceedToExport}
              className="flex items-center gap-2 px-5 py-2 text-xs font-semibold rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 transition-colors shadow-sm font-semibold"
            >
              <span>အဆင့် ၅ သို့ ဆက်သွားမည် (Next: Export & Save)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
