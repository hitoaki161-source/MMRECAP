import React, { useState, useEffect } from 'react';
import { Languages, Sparkles, Copy, Check, Download, ArrowRight, RefreshCw, Wand2, BookOpen } from 'lucide-react';
import { TranscriptionResult, TranslationResult, TranslationOptions } from '../types/recap';
import { apiFetch, translateError, AppError } from '../utils/apiClient';
import { ErrorAlert } from './ErrorAlert';

interface MyanmarTranslatorProps {
  transcription: TranscriptionResult | null;
  burmeseText: string;
  onBurmeseTextChange: (text: string) => void;
  onProceedToVoice: () => void;
}

export const MyanmarTranslator: React.FC<MyanmarTranslatorProps> = ({
  transcription,
  burmeseText,
  onBurmeseTextChange,
  onProceedToVoice,
}) => {
  const [style, setStyle] = useState<'recap' | 'dialogue' | 'summary'>('recap');
  const [tone, setTone] = useState<'dramatic' | 'conversational' | 'suspense' | 'humorous'>('dramatic');
  const [translating, setTranslating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusMessage, setStatusMessage] = useState('');
  const [error, setError] = useState<AppError | null>(null);
  const [copied, setCopied] = useState(false);

  const startTranslation = async () => {
    const originalText = transcription?.fullText || '';
    if (!originalText.trim()) {
      setError({
        messageEn: 'Original transcript is empty. Please complete transcription first or type text manually.',
        messageMy: 'မူရင်းစာသား မရှိသေးပါ။ အဆင့် ၂ တွင် စာသားအရင်ဖော်ယူပါ သို့မဟုတ် မူရင်းစာသားကို ရိုက်ထည့်ပေးပါ။',
        isRetryable: false,
      });
      return;
    }

    setError(null);
    setTranslating(true);
    setProgress(20);
    setStatusMessage('မြန်မာ ယူနီကုဒ် ရုပ်ရှင် Recap စတိုင်သို့ စတင်ပြောင်းလဲနေပါသည်...');

    try {
      const initRes = await apiFetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          originalText,
          style,
          tone,
        }),
      });

      const jobId = initRes.jobId;

      // Poll translation status
      const pollInterval = setInterval(async () => {
        try {
          const jobData = await apiFetch(`/api/jobs/${jobId}`);
          setProgress(jobData.progress || 0);
          setStatusMessage(jobData.statusMessageBurmese || 'လုပ်ဆောင်နေပါသည်...');

          if (jobData.status === 'completed') {
            clearInterval(pollInterval);
            setTranslating(false);
            if (jobData.result?.burmeseText) {
              onBurmeseTextChange(jobData.result.burmeseText);
            }
          } else if (jobData.status === 'failed') {
            clearInterval(pollInterval);
            setTranslating(false);
            setError({
              messageEn: jobData.error || 'Translation failed',
              messageMy: jobData.statusMessageBurmese || 'မြန်မာဘာသာပြန် ချွတ်ယွင်းမှု ဖြစ်ပွားခဲ့သည်',
              isRetryable: true,
            });
          }
        } catch (pollErr: any) {
          console.warn('Poll error:', pollErr);
        }
      }, 1500);
    } catch (err: any) {
      setTranslating(false);
      setError(translateError(err));
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(burmeseText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadScriptTxt = () => {
    const blob = new Blob([burmeseText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Myanmar_Recap_Script_${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Languages className="w-5 h-5 text-amber-400" />
            <span>အဆင့် ၃: မြန်မာဘာသာပြန်နှင့် Recap ဇာတ်ညွှန်း (Myanmar Recap Script)</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            Natural conversational Burmese suitable for engaging movie recap YouTube narration. Standard Unicode.
          </p>
        </div>

        {/* Translation Options Toolbar */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Style Selector */}
          <select
            value={style}
            onChange={(e) => setStyle(e.target.value as any)}
            disabled={translating}
            className="bg-neutral-900 border border-neutral-700 rounded-md px-3 py-1.5 text-xs text-neutral-200 focus:outline-none focus:border-amber-500"
          >
            <option value="recap">ရုပ်ရှင် Recap ဇာတ်ကြောင်းပြော စတိုင် (Recommended)</option>
            <option value="dialogue">တိကျသော စကားပြန် စတိုင် (Dialogue)</option>
            <option value="summary">အကျဉ်းချုပ် ဇာတ်လမ်း (Summary)</option>
          </select>

          {/* Tone Selector */}
          <select
            value={tone}
            onChange={(e) => setTone(e.target.value as any)}
            disabled={translating}
            className="bg-neutral-900 border border-neutral-700 rounded-md px-3 py-1.5 text-xs text-neutral-200 focus:outline-none focus:border-amber-500"
          >
            <option value="dramatic">ဇာတ်ရှိန်မြင့် / စိတ်ဝင်စားဖွယ် (Dramatic)</option>
            <option value="conversational">သဘာဝကျကျ စကားပြော (Conversational)</option>
            <option value="suspense">သည်းထိတ်ရင်ဖို (Suspense)</option>
            <option value="humorous">ဟာသနှော (Humorous)</option>
          </select>

          <button
            type="button"
            onClick={startTranslation}
            disabled={translating || !transcription?.fullText}
            className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold rounded-md bg-amber-500 hover:bg-amber-400 text-neutral-950 transition-colors shadow-sm disabled:opacity-50"
          >
            {translating ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Wand2 className="w-3.5 h-3.5" />
            )}
            <span>{translating ? 'ဘာသာပြန်နေသည်...' : 'Recap ဘာသာပြန်မည် (Translate)'}</span>
          </button>
        </div>
      </div>

      <ErrorAlert error={error} onRetry={startTranslation} onDismiss={() => setError(null)} retrying={translating} />

      {/* Prominent Translate Action Callout when no burmese text yet */}
      {!burmeseText.trim() && !translating && transcription?.fullText && (
        <div className="border border-neutral-800 bg-neutral-900/60 rounded-2xl p-6 text-center mb-6 shadow-xl">
          <div className="w-12 h-12 rounded-full bg-amber-500/10 text-amber-400 mx-auto flex items-center justify-center mb-3">
            <Wand2 className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-neutral-100 mb-1">
            မူရင်းစာသားကို မြန်မာ Recap စတိုင်သို့ စတင်ပြောင်းလဲပါ
          </h3>
          <p className="text-xs text-neutral-400 max-w-lg mx-auto mb-4">
            Convert dialogue into natural Burmese YouTube movie recap storytelling with scene transitions.
          </p>
          <button
            type="button"
            onClick={startTranslation}
            className="px-6 py-2.5 text-xs font-bold rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-[0.98] text-neutral-950 transition-all shadow-md cursor-pointer inline-flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>Recap ဇာတ်ညွှန်း စတင်ဘာသာပြန်မည် (Translate to Myanmar Recap)</span>
          </button>
        </div>
      )}

      {/* Translating Progress Indicator */}
      {translating && (
        <div className="border border-neutral-800 bg-neutral-900 rounded-xl p-6 mb-6">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-semibold text-neutral-200 flex items-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
              {statusMessage}
            </span>
            <span className="font-mono text-amber-400 tabular-nums">{progress}%</span>
          </div>
          <div className="w-full bg-neutral-800 rounded-full h-2 overflow-hidden">
            <div
              className="bg-amber-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      )}

      {/* Main Dual View or Dedicated Myanmar Script Box */}
      <div className="border border-neutral-800 bg-neutral-900 rounded-xl p-6">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-neutral-200">
              မြန်မာ ယူနီကုဒ် ဇာတ်ကြောင်းပြော စာသား (Myanmar Unicode Narration Script)
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={copyToClipboard}
              disabled={!burmeseText.trim()}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors border border-neutral-700 disabled:opacity-40"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'ကူးယူပြီးပါပြီ' : 'Copy Text'}</span>
            </button>

            <button
              type="button"
              onClick={downloadScriptTxt}
              disabled={!burmeseText.trim()}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors border border-neutral-700 disabled:opacity-40"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Script (TXT)</span>
            </button>
          </div>
        </div>

        {/* Editable Myanmar Text Area */}
        <textarea
          value={burmeseText}
          onChange={(e) => onBurmeseTextChange(e.target.value)}
          rows={14}
          className="w-full bg-neutral-950 border border-neutral-800 rounded-lg p-4 text-sm text-neutral-100 font-sans leading-relaxed focus:outline-none focus:border-amber-500 resize-y"
          placeholder="မြန်မာဘာသာပြန် ဇာတ်ကြောင်းပြော စာသား ဤနေရာတွင် ပေါ်လာပါမည် (တိုက်ရိုက် စိတ်ကြိုက် ပြင်ဆင်နိုင်ပါသည်)..."
        />

        {/* Tips & Character Counter */}
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-neutral-500">
          <div className="flex items-center gap-2">
            <span>💡 အသံမသွင်းမီ စာလုံးပေါင်းနှင့် ဇာတ်ကောင်အမည်များကို စိတ်ကြိုက် ပြင်ဆင်နိုင်ပါသည်။</span>
          </div>
          <div className="font-mono">
            စာလုံးရေ: <span className="text-neutral-300 tabular-nums">{burmeseText.length}</span> chars
          </div>
        </div>

        {/* Next Step Action */}
        <div className="flex items-center justify-end pt-5 mt-4 border-t border-neutral-800">
          <button
            type="button"
            onClick={onProceedToVoice}
            disabled={!burmeseText.trim()}
            className="flex items-center gap-2 px-5 py-2 text-xs font-semibold rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 transition-colors shadow-sm disabled:opacity-40 font-semibold"
          >
            <span>အဆင့် ၄ သို့ ဆက်သွားမည် (Next: Myanmar Voice Narration)</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
