import React from 'react';
import { Film, Radio, Cpu, RefreshCw, Settings, CheckCircle2, AlertTriangle } from 'lucide-react';
import { SystemHealth } from '../types/recap';

interface HeaderProps {
  health: SystemHealth | null;
  checkingHealth: boolean;
  onRefreshHealth: () => void;
  onOpenBackendModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  health,
  checkingHealth,
  onRefreshHealth,
  onOpenBackendModal,
}) => {
  const isHealthy = health?.status === 'healthy';
  const isDegraded = health?.status === 'degraded';

  return (
    <header className="flex items-center justify-between gap-8 px-6 py-4 border-b border-neutral-800 bg-neutral-900/90 backdrop-blur-md sticky top-0 z-30">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-sm">
          <Film className="w-5 h-5" />
        </div>
        <div>
          <span className="text-lg font-bold tracking-tight text-white whitespace-nowrap block">
            Myanmar Recap Studio
          </span>
          <span className="text-xs text-neutral-400 block -mt-1 font-normal">
            မြန်မာ ရုပ်ရှင် Recap စတူဒီယို
          </span>
        </div>
      </div>

      {/* Zone 2: Navigation / Info */}
      <div className="hidden md:flex items-center gap-6 text-xs text-neutral-400">
        <span className="hover:text-neutral-200 transition-colors whitespace-nowrap">
          Video Audio Extraction
        </span>
        <span aria-hidden="true" className="text-neutral-600">·</span>
        <span className="hover:text-neutral-200 transition-colors whitespace-nowrap">
          Speech Recognition
        </span>
        <span aria-hidden="true" className="text-neutral-600">·</span>
        <span className="hover:text-neutral-200 transition-colors whitespace-nowrap">
          Myanmar Unicode Recap
        </span>
        <span aria-hidden="true" className="text-neutral-600">·</span>
        <span className="hover:text-neutral-200 transition-colors whitespace-nowrap">
          Edge TTS Narration
        </span>
      </div>

      {/* Zone 3: Primary Action & Backend State */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onOpenBackendModal}
          className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md border border-neutral-700 bg-neutral-800/80 hover:bg-neutral-800 text-neutral-200 transition-colors"
          title="Configure Local Windows vs Cloud Backend"
        >
          {health?.activeBackend === 'local' ? (
            <Cpu className="w-3.5 h-3.5 text-blue-400" />
          ) : (
            <Radio className="w-3.5 h-3.5 text-amber-400" />
          )}
          <span>
            {health?.activeBackend === 'local' ? 'Local Windows (7860)' : 'Cloud Server'}
          </span>
          {isHealthy ? (
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          ) : isDegraded ? (
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
          ) : (
            <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
          )}
        </button>

        <button
          onClick={onRefreshHealth}
          disabled={checkingHealth}
          className="p-1.5 text-neutral-400 hover:text-neutral-100 hover:bg-neutral-800 rounded-md transition-colors"
          title="Refresh Backend Status"
        >
          <RefreshCw className={`w-4 h-4 ${checkingHealth ? 'animate-spin text-amber-400' : ''}`} />
        </button>
      </div>
    </header>
  );
};
