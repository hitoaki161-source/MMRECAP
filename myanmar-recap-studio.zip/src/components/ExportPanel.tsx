import React from 'react';
import { Download, FileText, Music, CheckCircle2, RotateCcw, Share2, Film, FolderDown, Monitor } from 'lucide-react';
import { VideoMetadata, TranscriptionResult, TTSResult } from '../types/recap';

interface ExportPanelProps {
  video: VideoMetadata | null;
  transcription: TranscriptionResult | null;
  burmeseText: string;
  ttsResult: TTSResult | null;
  onResetWorkflow: () => void;
  onOpenBackendModal: () => void;
}

export const ExportPanel: React.FC<ExportPanelProps> = ({
  video,
  transcription,
  burmeseText,
  ttsResult,
  onResetWorkflow,
  onOpenBackendModal,
}) => {
  const downloadTxt = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadAll = () => {
    // Download script
    if (burmeseText) {
      downloadTxt(burmeseText, `Myanmar_Recap_Script_${Date.now()}.txt`);
    }
    // Download SRT
    if (transcription?.srtContent) {
      setTimeout(() => {
        downloadTxt(transcription.srtContent, `Subtitles_${Date.now()}.srt`);
      }, 300);
    }
    // Download WAV
    if (ttsResult?.wavUrl) {
      setTimeout(() => {
        const a = document.createElement('a');
        a.href = ttsResult.wavUrl;
        a.download = `Myanmar_Recap_Voice_${ttsResult.audioId}.wav`;
        a.click();
      }, 600);
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="w-14 h-14 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 mx-auto flex items-center justify-center mb-3">
          <CheckCircle2 className="w-7 h-7" />
        </div>
        <h2 className="text-2xl font-bold text-white tracking-tight">
          Recap ဖန်တီးမှု ပြီးမြောက်ပါပြီ (Project Completed)
        </h2>
        <p className="text-xs text-neutral-400 mt-1 max-w-lg mx-auto">
          Your transcript, Myanmar movie recap script, and studio-grade voice narration audio files are generated and ready for download.
        </p>
      </div>

      {/* Deliverables Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {/* Audio Deliverable Card */}
        <div className="border border-neutral-800 bg-neutral-900 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
                <Music className="w-5 h-5" />
              </span>
              <span className="text-[11px] font-mono text-neutral-400">
                {ttsResult ? `${(ttsResult.fileSizeBytes / (1024 * 1024)).toFixed(2)} MB` : 'Pending'}
              </span>
            </div>
            <h3 className="font-semibold text-sm text-neutral-100">
              မြန်မာ ဇာတ်ကြောင်းပြော အသံဖိုင် (Audio Narration)
            </h3>
            <p className="text-xs text-neutral-400 mt-1">
              Generated via Microsoft Edge TTS ({ttsResult?.voiceUsed || 'my-MM-NilarNeural'}), master WAV and MP3 formats.
            </p>
          </div>

          <div className="mt-5 flex gap-2">
            {ttsResult?.wavUrl ? (
              <a
                href={ttsResult.wavUrl}
                download
                className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>WAV ဒေါင်းလုဒ်</span>
              </a>
            ) : null}

            {ttsResult?.mp3Url ? (
              <a
                href={ttsResult.mp3Url}
                download
                className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-medium rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>MP3 ဒေါင်းလုဒ်</span>
              </a>
            ) : null}
          </div>
        </div>

        {/* Script & Subtitles Deliverable Card */}
        <div className="border border-neutral-800 bg-neutral-900 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
                <FileText className="w-5 h-5" />
              </span>
              <span className="text-[11px] font-mono text-neutral-400">
                {burmeseText ? `${burmeseText.length} Chars` : 'Pending'}
              </span>
            </div>
            <h3 className="font-semibold text-sm text-neutral-100">
              မြန်မာ Recap ဇာတ်ညွှန်းနှင့် စာတန်းထိုး (Script & SRT)
            </h3>
            <p className="text-xs text-neutral-400 mt-1">
              Natural Myanmar Unicode recap text file and synchronized SRT subtitle timeline.
            </p>
          </div>

          <div className="mt-5 flex gap-2">
            <button
              type="button"
              onClick={() => downloadTxt(burmeseText, `Myanmar_Recap_Script_${Date.now()}.txt`)}
              disabled={!burmeseText}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-medium rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 transition-colors disabled:opacity-40"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Script (TXT)</span>
            </button>

            <button
              type="button"
              onClick={() => downloadTxt(transcription?.srtContent || '', `Subtitles_${Date.now()}.srt`)}
              disabled={!transcription?.srtContent}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-medium rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 transition-colors disabled:opacity-40"
            >
              <Download className="w-3.5 h-3.5" />
              <span>SRT Subtitle</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary Download All Action */}
      <div className="text-center mb-8">
        <button
          type="button"
          onClick={handleDownloadAll}
          className="inline-flex items-center gap-2 px-8 py-3 text-sm font-semibold rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 transition-colors shadow-lg shadow-amber-500/10"
        >
          <FolderDown className="w-4 h-4" />
          <span>ဖိုင်အားလုံး တစ်ပြိုင်နက် ဒေါင်းလုဒ်ရယူပါ (Download All Assets)</span>
        </button>
      </div>

      {/* Windows Local Mode Notice */}
      <div className="border border-neutral-800 bg-neutral-900/60 rounded-xl p-5 mb-8 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
            <Monitor className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-neutral-200">
              Windows 10 / 11 တွင် ဒေသတွင်း အသုံးပြုလိုပါသလား။ (Run Locally)
            </h4>
            <p className="text-xs text-neutral-400 mt-0.5">
              Run offline with faster-whisper CPU/GPU processing via <code className="text-blue-300">backend/start.bat</code>.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onOpenBackendModal}
          className="px-4 py-2 text-xs font-semibold rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 transition-colors whitespace-nowrap"
        >
          Backend လမ်းညွှန်ကြည့်ရန် (Configure)
        </button>
      </div>

      {/* Reset & New Video Button */}
      <div className="text-center">
        <button
          type="button"
          onClick={onResetWorkflow}
          className="inline-flex items-center gap-2 text-xs text-neutral-400 hover:text-neutral-200 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>နောက်ထပ် ဗီဒီယိုအသစ်တစ်ခု ဖန်တီးမည် (Start New Video Recap)</span>
        </button>
      </div>
    </div>
  );
};
