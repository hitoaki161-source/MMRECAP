import React, { useState, useRef } from 'react';
import { Upload, Film, AlertCircle, CheckCircle2, Music, ArrowRight, Play, RefreshCw, Sparkles } from 'lucide-react';
import { VideoMetadata } from '../types/recap';
import { translateError, AppError, getActiveBackendConfig } from '../utils/apiClient';
import { ErrorAlert } from './ErrorAlert';

interface VideoUploaderProps {
  onVideoUploaded: (meta: VideoMetadata) => void;
  currentVideo: VideoMetadata | null;
  onProceedToTranscribe: (autoStart?: boolean, videoMeta?: VideoMetadata) => void;
}

export const VideoUploader: React.FC<VideoUploaderProps> = ({
  onVideoUploaded,
  currentVideo,
  onProceedToTranscribe,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState<AppError | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [browserPreviewError, setBrowserPreviewError] = useState(false);

  const supportedFormats = ['.mp4', '.mov', '.mkv', '.webm', '.avi', '.mp3', '.m4a', '.wav'];

  const validateFile = (file: File): boolean => {
    const ext = '.' + file.name.split('.').pop()?.toLowerCase();
    if (!supportedFormats.includes(ext) && !file.type.startsWith('video/') && !file.type.startsWith('audio/')) {
      setError({
        messageEn: `File format '${ext}' is not supported. Please upload MP4, MOV, MKV, or WebM.`,
        messageMy: `'${ext}' ဖိုင်အမျိုးအစားကို လက်မခံပါ။ စံ MP4, MOV, MKV သို့မဟုတ် WebM ဗီဒီယိုဖိုင်များကိုသာ တင်ပေးပါ။`,
        isRetryable: false,
        code: 'UNSUPPORTED_MEDIA',
      });
      return false;
    }

    // 500MB Limit check
    const maxBytes = 500 * 1024 * 1024;
    if (file.size > maxBytes) {
      setError({
        messageEn: 'File size exceeds 500MB limit. Please provide a trimmed video clip.',
        messageMy: 'ဖိုင်အရွယ်အစား 500MB ထက် ကျော်လွန်နေပါသည်။ ပိုမိုသေးငယ်သော ဗီဒီယိုဖိုင်ကို တင်ပေးပါ။',
        isRetryable: false,
        code: 'PAYLOAD_TOO_LARGE',
      });
      return false;
    }

    return true;
  };

  const uploadFile = async (file: File) => {
    if (!validateFile(file)) return;

    setError(null);
    setUploading(true);
    setUploadProgress(10);
    setBrowserPreviewError(false);

    const formData = new FormData();
    formData.append('video', file, file.name);

    const { baseUrl } = getActiveBackendConfig();
    const endpoint = `${baseUrl}/api/upload`;

    try {
      // Use XMLHttpRequest for accurate upload progress tracking
      const xhr = new XMLHttpRequest();
      xhr.open('POST', endpoint);

      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) {
          const percent = Math.round((event.loaded / event.total) * 90);
          setUploadProgress(percent);
        }
      };

      const promise = new Promise<any>((resolve, reject) => {
        xhr.onload = () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            try {
              const parsed = typeof xhr.responseText === 'string' ? JSON.parse(xhr.responseText) : xhr.responseText;
              const safeName = parsed?.filename || parsed?.fileName;
              if (!safeName) {
                reject(new Error('Server upload completed successfully but did not return a valid filename.'));
                return;
              }
              resolve(parsed);
            } catch (err: any) {
              reject(new Error(`Failed to parse upload server response: ${err.message}`));
            }
          } else {
            let errDetail: any;
            try {
              errDetail = JSON.parse(xhr.responseText);
            } catch {
              errDetail = { detail: xhr.statusText };
            }
            const err: any = new Error(errDetail?.detail || errDetail?.error || `Upload failed with HTTP ${xhr.status}`);
            err.status = xhr.status;
            reject(err);
          }
        };
        xhr.onerror = () => {
          const err: any = new Error('Network error during file upload');
          err.code = 'NETWORK_ERROR';
          reject(err);
        };
      });

      xhr.send(formData);
      const res = await promise;

      const safeFilename = res.filename || res.fileName;
      if (!safeFilename) {
        throw new Error('Upload succeeded but server did not return a valid filename.');
      }

      const uploadedMeta: VideoMetadata = {
        filename: safeFilename,
        originalName: res.originalName || file.name,
        size: res.size || file.size,
        mimeType: res.mimeType || file.type,
        hasAudio: res.hasAudio !== false,
        videoUrl: res.videoUrl ? `${baseUrl}${res.videoUrl}` : undefined,
        uploadedAt: new Date().toLocaleTimeString(),
      };

      setUploadProgress(100);
      onVideoUploaded(uploadedMeta);
    } catch (err: any) {
      setError(translateError(err));
    } finally {
      setUploading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      uploadFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      uploadFile(e.target.files[0]);
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Hidden file input for file selection */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/*,audio/*,.mkv,.mp4,.mov,.webm"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Step Header */}
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Film className="w-5 h-5 text-amber-400" />
            <span>အဆင့် ၁: ဗီဒီယိုဖိုင် တင်သွင်းပါ (Upload Movie / Video)</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            Supports MP4, MOV, MKV, WebM. Audio will be automatically extracted using FFmpeg.
          </p>
        </div>

        {currentVideo && currentVideo.filename && (
          <button
            type="button"
            onClick={() => onProceedToTranscribe(true, currentVideo)}
            aria-label="Start Transcription and Translation"
            className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 transition-all shadow-md active:scale-[0.98] cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Start Transcription & Translation</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      <ErrorAlert error={error} onDismiss={() => setError(null)} />

      {/* Uploading progress notification */}
      {uploading && (
        <div className="mb-6 border border-neutral-800 bg-neutral-900 rounded-xl p-6 max-w-xl mx-auto">
          <div className="flex items-center justify-between text-xs text-neutral-300 mb-2 font-medium">
            <span className="flex items-center gap-2">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
              <span>ဗီဒီယိုဖိုင် တင်သွင်းနေပါသည် (Uploading video)...</span>
            </span>
            <span className="font-mono text-amber-400">{uploadProgress}%</span>
          </div>
          <div className="w-full bg-neutral-800 rounded-full h-2 overflow-hidden">
            <div
              className="bg-amber-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${uploadProgress}%` }}
            />
          </div>
          <p className="text-[11px] text-neutral-500 mt-2 text-center">
            FFmpeg will automatically detect and verify the audio stream upon completion.
          </p>
        </div>
      )}

      {/* If a video is already uploaded, show the Video Card prominently */}
      {currentVideo && currentVideo.filename ? (
        <div className="border border-neutral-800 bg-neutral-900 rounded-2xl p-6 shadow-2xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 shrink-0 mt-0.5">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 mb-1">
                  <span>ဗီဒီယို တင်သွင်းမှု အောင်မြင်သည် (Upload Ready)</span>
                </div>
                <h3 className="font-bold text-base text-neutral-100 break-all">{currentVideo.originalName}</h3>
                <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-400 mt-1">
                  <span className="font-mono tabular-nums text-neutral-300">{formatFileSize(currentVideo.size)}</span>
                  <span aria-hidden="true">·</span>
                  <span>{currentVideo.mimeType || 'Video'}</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-emerald-400 flex items-center gap-1">
                    <Music className="w-3.5 h-3.5" /> FFmpeg Audio Stream Verified
                  </span>
                </div>
              </div>
            </div>

            {/* Primary Action Button */}
            <button
              type="button"
              onClick={() => onProceedToTranscribe(true, currentVideo)}
              aria-label="Start Transcription and Translation"
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 text-sm font-bold rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-[0.98] text-neutral-950 transition-all shadow-lg shadow-amber-500/10 hover:shadow-amber-500/25 shrink-0 focus:outline-none focus:ring-2 focus:ring-amber-400 cursor-pointer"
            >
              <span>Start Transcription & Translation</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Browser Video Preview Section with fallback */}
          {currentVideo.videoUrl && (
            <div>
              <div className="text-xs text-neutral-400 mb-2 font-medium flex items-center gap-1.5">
                <Play className="w-3.5 h-3.5 text-amber-400" />
                <span>Video Preview (အစမ်းကြည့်ရှုခြင်း)</span>
              </div>

              {!browserPreviewError ? (
                <div className="rounded-xl overflow-hidden bg-black border border-neutral-800 max-h-80 flex items-center justify-center shadow-inner">
                  <video
                    src={currentVideo.videoUrl}
                    controls
                    onError={() => setBrowserPreviewError(true)}
                    className="max-h-80 w-full object-contain"
                  />
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 text-xs text-neutral-400 flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-neutral-200 font-semibold block mb-0.5">
                      Browser preview unavailable for this codec/container (MKV/HEVC/ProRes).
                    </span>
                    <span>
                      Don't worry! FFmpeg native server decoding will extract the audio and transcribe the speech normally.
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Bottom Action Footer with Accessible Button & Replace Video Option */}
          <div className="pt-4 border-t border-neutral-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="text-xs text-neutral-400 hover:text-neutral-200 transition-colors flex items-center justify-center gap-1.5 py-2 px-3.5 rounded-lg border border-neutral-800 hover:border-neutral-700 bg-neutral-950/60 cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-neutral-400" />
              <span>အခြားဗီဒီယိုဖိုင် အသစ်ရွေးချယ်မည် (Upload Different Video)</span>
            </button>

            <button
              type="button"
              onClick={() => onProceedToTranscribe(true, currentVideo)}
              aria-label="Start Transcription and Translation"
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 text-xs font-bold rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 transition-colors shadow-sm cursor-pointer"
            >
              <span>စကားပြောစာသားဖော်ယူပြီး မြန်မာပြန်ဆိုမည် (Start Transcription & Translation)</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      ) : (
        /* Drag & Drop Upload Container when no video is uploaded yet */
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-2xl p-10 text-center transition-all ${
            isDragging
              ? 'border-amber-400 bg-amber-500/10'
              : 'border-neutral-800 bg-neutral-900/50 hover:border-neutral-700'
          }`}
        >
          <div className="w-16 h-16 rounded-full bg-neutral-800 border border-neutral-700 mx-auto flex items-center justify-center text-amber-400 mb-4 shadow-inner">
            <Upload className="w-7 h-7" />
          </div>

          <h3 className="text-base font-semibold text-neutral-200 mb-1">
            ဗီဒီယိုဖိုင်ကို ဤနေရာသို့ ဆွဲထည့်ပါ သို့မဟုတ် ရွေးချယ်ပါ
          </h3>
          <p className="text-xs text-neutral-400 mb-5">
            Drag and drop movie file here, or click to browse from your computer
          </p>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="px-6 py-3 text-xs font-bold rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 transition-all shadow-md active:scale-[0.98] disabled:opacity-50 cursor-pointer"
          >
            {uploading ? 'ဖိုင်တင်သွင်းနေပါသည်...' : 'ဗီဒီယိုဖိုင် ရွေးချယ်မည် (Select Video)'}
          </button>

          <div className="mt-5 flex items-center justify-center gap-4 text-xs text-neutral-500">
            <span>MP4 / MKV / MOV / WebM</span>
            <span aria-hidden="true">·</span>
            <span>Max: 500 MB</span>
            <span aria-hidden="true">·</span>
            <span>FFmpeg Native Audio Extraction</span>
          </div>
        </div>
      )}
    </div>
  );
};
