/**
 * Myanmar Recap Studio - Main Application Component
 * A full-stack movie recap audio and transcript studio.
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { StepNavigation } from './components/StepNavigation';
import { VideoUploader } from './components/VideoUploader';
import { TranscriptEditor } from './components/TranscriptEditor';
import { MyanmarTranslator } from './components/MyanmarTranslator';
import { VoiceGenerator } from './components/VoiceGenerator';
import { ExportPanel } from './components/ExportPanel';
import { BackendModal } from './components/BackendModal';
import { RecapStep, VideoMetadata, TranscriptionResult, TTSResult, SystemHealth } from './types/recap';
import { apiFetch, getActiveBackendConfig } from './utils/apiClient';
import studioBanner from './assets/images/recap_studio_banner_1792326649249.jpg';
import { Sparkles, Film, Mic, Volume2 } from 'lucide-react';

export default function App() {
  const [currentStep, setCurrentStep] = useState<RecapStep>('upload');
  const [video, setVideo] = useState<VideoMetadata | null>(() => {
    try {
      const saved = sessionStorage.getItem('recap_current_video');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed.filename === 'string' && parsed.filename.trim()) {
          return parsed;
        }
      }
    } catch {}
    return null;
  });
  const [transcription, setTranscription] = useState<TranscriptionResult | null>(null);
  const [burmeseText, setBurmeseText] = useState<string>('');
  const [ttsResult, setTtsResult] = useState<TTSResult | null>(null);
  const [autoStartTranscribe, setAutoStartTranscribe] = useState<boolean>(false);

  // Health and Backend Modal state
  const [health, setHealth] = useState<SystemHealth | null>(null);
  const [checkingHealth, setCheckingHealth] = useState<boolean>(false);
  const [backendModalOpen, setBackendModalOpen] = useState<boolean>(false);

  // Check backend health
  const checkHealth = useCallback(async () => {
    setCheckingHealth(true);
    try {
      const data = await apiFetch<SystemHealth>('/api/health');
      setHealth(data);
    } catch (err) {
      console.warn('Backend health check warning:', err);
      const config = getActiveBackendConfig();
      setHealth({
        status: 'offline',
        ffmpegAvailable: false,
        ttsAvailable: false,
        aiAvailable: false,
        activeBackend: config.mode,
        localUrl: config.baseUrl,
      });
    } finally {
      setCheckingHealth(false);
    }
  }, []);

  useEffect(() => {
    checkHealth();
  }, [checkHealth]);

  const completedSteps = {
    upload: !!video && typeof video.filename === 'string' && video.filename.trim().length > 0,
    transcribe: !!transcription,
    translate: !!burmeseText.trim(),
    voice: !!ttsResult,
    export: !!ttsResult && !!burmeseText,
  };

  const handleVideoUploaded = (meta: VideoMetadata) => {
    if (meta && meta.filename) {
      try {
        sessionStorage.setItem('recap_current_video', JSON.stringify(meta));
      } catch {}
      setVideo(meta);
    }
  };

  const handleTranscriptionComplete = (result: TranscriptionResult) => {
    setTranscription(result);
  };

  const handleBurmeseTextChange = (text: string) => {
    setBurmeseText(text);
  };

  const handleTTSComplete = (result: TTSResult) => {
    setTtsResult(result);
  };

  const handleResetWorkflow = () => {
    if (window.confirm('Recap ပရောဂျက်အသစ် စတင်လိုပါသလား။ (Start a new video recap project?)')) {
      try {
        sessionStorage.removeItem('recap_current_video');
      } catch {}
      setVideo(null);
      setTranscription(null);
      setBurmeseText('');
      setTtsResult(null);
      setCurrentStep('upload');
    }
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans">
      {/* Top Bar */}
      <Header
        health={health}
        checkingHealth={checkingHealth}
        onRefreshHealth={checkHealth}
        onOpenBackendModal={() => setBackendModalOpen(true)}
      />

      {/* Step Navigation Bar */}
      <StepNavigation
        currentStep={currentStep}
        onSelectStep={(step) => setCurrentStep(step)}
        completedSteps={completedSteps}
      />

      {/* Main Workspace Viewport */}
      <main className="flex-1">
        {/* Hero Banner on Step 1 if no video uploaded yet */}
        {currentStep === 'upload' && !video && (
          <div className="max-w-4xl mx-auto px-4 pt-6 pb-2">
            <div className="relative rounded-2xl overflow-hidden border border-neutral-800 bg-neutral-900 shadow-2xl">
              <img
                src={studioBanner}
                alt="Myanmar Recap Studio Production Timeline"
                referrerPolicy="no-referrer"
                className="w-full h-48 md:h-64 object-cover opacity-60"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/60 to-transparent flex flex-col justify-end p-6 md:p-8">
                <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded bg-amber-500/20 text-amber-400 text-xs font-semibold mb-2 w-fit border border-amber-500/30">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>စတင်အသုံးပြုရန် အသင့်ဖြစ်ပါပြီ (Production Ready)</span>
                </div>
                <h1 className="text-xl md:text-3xl font-bold text-white tracking-tight">
                  ရုပ်ရှင် Recap ဇာတ်ကြောင်းပြောနှင့် စာတန်းထိုး ဖန်တီးမှု စတူဒီယို
                </h1>
                <p className="text-xs md:text-sm text-neutral-300 mt-2 max-w-2xl leading-relaxed">
                  Upload video, extract dialogues via Whisper/FFmpeg, craft natural Myanmar recap narration, and generate authentic Microsoft Edge TTS Burmese voiceovers.
                </p>

                {/* Studio Highlights */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-4 border-t border-neutral-800/80 text-xs">
                  <div className="flex items-center gap-2 text-neutral-300">
                    <Film className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>FFmpeg Codecs</span>
                  </div>
                  <div className="flex items-center gap-2 text-neutral-300">
                    <Mic className="w-4 h-4 text-blue-400 shrink-0" />
                    <span>Whisper Audio STT</span>
                  </div>
                  <div className="flex items-center gap-2 text-neutral-300">
                    <Volume2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Edge TTS (Nilar & Thiha)</span>
                  </div>
                  <div className="flex items-center gap-2 text-neutral-300">
                    <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
                    <span>Myanmar Unicode</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step Views */}
        {currentStep === 'upload' && (
          <VideoUploader
            onVideoUploaded={handleVideoUploaded}
            currentVideo={video}
            onProceedToTranscribe={(autoStart = true, meta?: VideoMetadata) => {
              const verified = meta && meta.filename ? meta : video;
              if (verified && verified.filename) {
                handleVideoUploaded(verified);
              }
              setAutoStartTranscribe(autoStart);
              setCurrentStep('transcribe');
            }}
          />
        )}

        {currentStep === 'transcribe' && (
          <TranscriptEditor
            video={video}
            transcription={transcription}
            onTranscriptionComplete={handleTranscriptionComplete}
            onProceedToTranslate={() => setCurrentStep('translate')}
            autoStart={autoStartTranscribe}
            onAutoStartHandled={() => setAutoStartTranscribe(false)}
          />
        )}

        {currentStep === 'translate' && (
          <MyanmarTranslator
            transcription={transcription}
            burmeseText={burmeseText}
            onBurmeseTextChange={handleBurmeseTextChange}
            onProceedToVoice={() => setCurrentStep('voice')}
          />
        )}

        {currentStep === 'voice' && (
          <VoiceGenerator
            burmeseText={burmeseText}
            ttsResult={ttsResult}
            onTTSComplete={handleTTSComplete}
            onProceedToExport={() => setCurrentStep('export')}
          />
        )}

        {currentStep === 'export' && (
          <ExportPanel
            video={video}
            transcription={transcription}
            burmeseText={burmeseText}
            ttsResult={ttsResult}
            onResetWorkflow={handleResetWorkflow}
            onOpenBackendModal={() => setBackendModalOpen(true)}
          />
        )}
      </main>

      {/* Backend Settings & Windows Setup Modal */}
      <BackendModal
        isOpen={backendModalOpen}
        onClose={() => setBackendModalOpen(false)}
        health={health}
        onRefreshHealth={checkHealth}
      />

      {/* Footer */}
      <footer className="border-t border-neutral-800/80 bg-neutral-900/50 py-4 px-6 text-xs text-neutral-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            Myanmar Recap Studio © 2026 · မြန်မာ ရုပ်ရှင် Recap စတူဒီယို
          </div>
          <div className="flex items-center gap-4 text-neutral-400">
            <button
              onClick={() => setBackendModalOpen(true)}
              className="hover:text-neutral-200 transition-colors"
            >
              Windows Setup (start.bat)
            </button>
            <span aria-hidden="true">·</span>
            <span>Edge TTS: my-MM-NilarNeural / my-MM-ThihaNeural</span>
            <span aria-hidden="true">·</span>
            <span>Standard Myanmar Unicode</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
