export type RecapStep = 'upload' | 'transcribe' | 'translate' | 'voice' | 'export';

export interface VideoMetadata {
  filename: string;
  originalName: string;
  size: number;
  mimeType: string;
  duration?: number;
  hasAudio?: boolean;
  videoUrl?: string;
  extractedAudioPath?: string;
  uploadedAt: string;
}

export interface TranscriptSegment {
  id: number;
  start: string; // e.g. "00:00:01"
  end: string;   // e.g. "00:00:05"
  speaker?: string;
  text: string;
}

export interface TranscriptionResult {
  fullText: string;
  detectedLanguage?: string;
  segments: TranscriptSegment[];
  srtContent: string;
}

export interface TranslationOptions {
  style: 'recap' | 'dialogue' | 'summary';
  keepTimestamps: boolean;
  tone: 'dramatic' | 'conversational' | 'suspense' | 'humorous';
}

export interface TranslationResult {
  burmeseText: string;
  style: string;
  segments?: {
    id: number;
    start: string;
    end: string;
    burmeseText: string;
  }[];
}

export interface VoiceOption {
  id: 'my-MM-NilarNeural' | 'my-MM-ThihaNeural';
  name: string;
  gender: 'female' | 'male';
  description: string;
  previewSample?: string;
}

export interface TTSOptions {
  voiceId: 'my-MM-NilarNeural' | 'my-MM-ThihaNeural';
  rate: string; // e.g. "+0%", "+10%", "-10%"
  pitch: string; // e.g. "+0Hz", "+5Hz"
  volume: string;
}

export interface TTSResult {
  audioId: string;
  wavUrl: string;
  mp3Url: string;
  durationSeconds: number;
  voiceUsed: string;
  fileSizeBytes: number;
}

export interface JobStatus {
  jobId: string;
  type: 'extract' | 'transcribe' | 'translate' | 'tts';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  statusMessageBurmese: string;
  statusMessageEnglish: string;
  result?: any;
  error?: string;
  createdAt: number;
}

export interface SystemHealth {
  status: 'healthy' | 'degraded' | 'offline';
  ffmpegAvailable: boolean;
  ffmpegVersion?: string;
  ttsAvailable: boolean;
  aiAvailable: boolean;
  activeBackend: 'cloud' | 'local';
  localUrl?: string;
}
